# ZENT// — ZentEncrypted

Self-hosted chat you can run on a Raspberry Pi. Browser only, nothing to install for users.

- **Public room** — open to everyone. Its messages are **saved** on your server (see below).
- **Join-code rooms** — end-to-end encrypted. You pick how long they live; they delete themselves.
- **Friends** — add by friend code and message any time. Messages wait for them, end-to-end encrypted.
- **Link** — one-off peer-to-peer chat between two browsers.
- **Guests welcome** — no signup needed.

Node.js + Express + Socket.io on the back, plain HTML/CSS/JS on the front. No build step, no CDNs, no third-party requests. Fonts, icons and the PeerJS library are all served from your own server.

---

## What the server can and can't see

Be clear-eyed about this; it's the whole point.

| Where | Encrypted? | What your server sees |
|---|---|---|
| **#public** | **No.** It's public. | The text, **and it is saved to disk** (name, time, text; no IP addresses) so newcomers can scroll back. |
| **Join-code rooms** | Yes, end to end | Scrambled bytes, who's in the room, room name, when it expires. Never the code or the key. **Never saved.** |
| **Friend chats** | Yes, end to end | Scrambled bytes (kept until read and beyond, so either side can scroll back), each person's public key, and a **password-locked** copy of each private key. Never the text or an unlocked key. |
| **Link (P2P)** | Yes, twice over | Only the brief connection handshake. The conversation never touches the server. |

**Join-code rooms leave no history.** They exist on screen only: close the tab and they're gone. Friend messages are stored, but only as ciphertext the server can't read. The public room's messages are written to `data/public-history.jsonl` on your server, and the bar above the chat says so, so nobody mistakes it for private.

### The public room's saved history

- **What's stored per message:** an id, the time, the display name, a pseudonymous user id (an HMAC, not the real account id), and the text. No IP addresses.
- **Only the public room.** Encrypted rooms and friend chats never reach this code (there are tests proving it).
- **You control how long it's kept** (`.env`):
  - `PUBLIC_HISTORY_DAYS=30` (the default) deletes messages after 30 days. `0` keeps them until you delete them.
  - `PUBLIC_HISTORY_MAX=50000` caps the total; the oldest go first.
  - `PUBLIC_HISTORY=0` turns saving off completely.
- **Deleting things.** Stop the server first, then run the cleanup tool:
  ```bash
  pm2 stop zentencrypted
  npm run purge-public -- --user SomeName      # everything one display name posted
  npm run purge-public -- --match "bad words"  # any message containing this text
  npm run purge-public -- --older-than 30      # older than 30 days
  npm run purge-public -- --all                # wipe it all
  npm run purge-public -- --all --dry-run      # preview without changing anything
  pm2 start zentencrypted
  ```
  The tool refuses to run while the server is up, because changing the file underneath it can lose new messages or bring deleted ones back.
- **Back it up or delete it with the account data:** it's just one text file next to `db.json`.
- **If people under 18 use your site,** think about how long you keep what they write and whether they know it's saved. Your call, but decide on purpose.

### How the keys work

- **Join-code rooms:** the code `LLLL-SSSS-SSSS-SSSS` has a public part (`LLLL`, finds the room) and a 60-bit secret. Your browser stretches the secret with PBKDF2 (150,000 rounds) into two independent halves: one is sent to the server to prove you know the code (the server stores only a hash of it), the other becomes the AES-256-GCM key and **never leaves your browser**.
- **Friend chats:** every account has one long-term key pair. The private half is locked in your browser with a key derived from your password (PBKDF2, 310,000 rounds) and stored on the server in that locked form, so any of your devices can unlock it after you sign in. Each friendship's messages use an AES-256-GCM key derived from ECDH between the two long-term keys, so messages can wait for an offline friend and both of you can read the history on any device. The **safety code** (a hash of both public keys) is stable for the friendship: compare it once in person, and the app warns you if a friend's key ever changes.
- Every message is bound to its room, so a ciphertext can't be replayed into another room.

### Honest limitations

- **Forget your password and your old friend messages are gone.** The key that unlocks them comes from your password, and there's no reset that keeps them.
- **It's a web app.** The server delivers the code that does the encryption, so someone who takes over your server could serve code that steals keys. End-to-end encryption here protects against people who get your stored data, not against a compromised server.
- **No forward secrecy.** For join-code rooms, anyone who later learns the code can read anything they captured earlier. Friend-chat keys are per-session, which helps, but this isn't Signal. For high-stakes secrets, use a vetted protocol.
- **Guest friendships live in server memory.** A server restart or the 24-hour expiry wipes them.
- **Translation only works in recent Chrome/Edge.** It uses the browser's built-in on-device translator. There's deliberately no cloud fallback: that would hand your messages to a third party.
- **Link (P2P)** uses Google's public STUN server to get through home routers (PeerJS's default). Strict networks (symmetric NAT) may fail to connect; there's no server relay by design. A self-hosted TURN server (coturn) is the fix if you need it.
- **Moderation is manual.** There are no in-app moderation tools; you can delete saved messages with the cleanup tool, but a message is visible live until you do. Don't expose the public room more widely than you're willing to watch.

---

## Setup

Node 18+ required.

```bash
npm install --omit=dev
cp .env.example .env
nano .env        # set JWT_SECRET
npm start
```

Make a secret:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Open `http://localhost:3000`.

### Keep it running (pm2)

```bash
sudo npm install -g pm2
pm2 start server.js --name zentencrypted
pm2 save
pm2 startup        # then run the line it prints
```

### Updating an existing install (Raspberry Pi)

Your accounts live in `data/db.json` and your secret lives in `.env`. **Copy both** or people lose their accounts:

```bash
cd ~
mv ZentEncrypted ZentEncrypted-old
# copy the new folder in as ~/ZentEncrypted, then:
cd ~/ZentEncrypted
cp ../ZentEncrypted-old/.env .env
cp -r ../ZentEncrypted-old/data ./data
npm install --omit=dev
pm2 restart zentencrypted
```

Check it: `curl http://localhost:3000/health` should print `{"ok":true}`.

### Behind Cloudflare Tunnel (what you're running)

Nothing special is needed. The server reads the real visitor IP from `CF-Connecting-IP` **only** when the request comes from this same machine (`cloudflared`), so rate limits apply per visitor instead of to the whole site at once. Login cookies are marked `Secure` automatically when the request arrived over HTTPS, and work over plain `http://` on your LAN too.

---

## Configuration (`.env`)

| Variable | Default | What it does |
|---|---|---|
| `JWT_SECRET` | *(required)* | Signs login sessions. 32+ random characters. |
| `PORT` | `3000` | Port to listen on. |
| `PUBLIC_URL` | *(empty)* | Your https address. Shown as a link when someone opens the site over plain http. |
| `HOST` | *(all interfaces)* | `127.0.0.1` makes the app reachable only through the tunnel. |
| `ROOM_MIN_TTL_MS` / `ROOM_MAX_TTL_MS` | 5 min / 7 days | Allowed room lifetimes. |
| `MAX_ROOMS_PER_USER` / `MAX_ROOMS_TOTAL` | 5 / 500 | Caps on active join-code rooms. |
| `WS_MAX_MESSAGES_PER_SECOND` | 5 | Per-connection message limit. |
| `WS_IDLE_TIMEOUT_MS` | 15 min | Idle connections are dropped (the page pings while you're active). |
| `PUBLIC_HISTORY` | 1 | Save the public room's messages. `0` turns it off. |
| `PUBLIC_HISTORY_DAYS` | 30 | Delete saved public messages older than this. `0` keeps them until you delete them. |
| `PUBLIC_HISTORY_MAX` | 50000 | Most public messages kept; the oldest are dropped first. |
| `DM_HISTORY_DAYS` | 0 | Delete friend messages older than this. `0` keeps them. |
| `DM_HISTORY_MAX` | 200000 | Most friend messages kept in total (oldest dropped first). |
| `SHIELD_ENABLED` | 1 | The human check (below). |
| `SHIELD_ALWAYS` | 0 | Set to `1` to make **everyone** do it while you're under attack. |
| `SHIELD_AUTH_SOFT` | 10 | Sign-in attempts per minute from one network before it kicks in. |
| `MAX_CONN_PER_IP` | 250 | Concurrent connections per network (high on purpose: schools share one IP). |

### The human check (anti-bot)

No third-party captcha. When a network sends lots of sign-in/register/guest requests, fails logins repeatedly, or the whole site is being flooded, the server asks the browser to do a small proof-of-work puzzle (about a second of CPU, more if it's misbehaving). Normal visitors never see it. Each puzzle is single-use and tied to the requester's network. For real volumetric attacks, keep Cloudflare in front: this protects the app, Cloudflare protects the pipe.

---


## Security

What's in place, and where:

| Threat | Protection |
|---|---|
| Password guessing / credential stuffing | Per-network rate limits; a proof-of-work check for floods; **per-account** check after 5 misses (stops guessing spread over many IPs, without locking the owner out); common and username-based passwords refused. |
| Stolen password hashes | scrypt (N=2^15). Old bcrypt hashes are upgraded on the next sign-in. Unknown usernames take as long as wrong passwords. |
| Stolen or lost device | Change password signs out every other device and drops their live connections. "Sign out everywhere" kills every session. |
| XSS | User text only ever rendered with `textContent`; strict CSP (no inline scripts or styles, no third-party hosts). No HTML/rich text is accepted, so no sanitiser is needed. |
| CSRF | Cookies are `SameSite=Lax`; state-changing API calls from other sites are refused (Origin / Sec-Fetch-Site checks); WebSockets check Origin too. |
| Access control (IDOR) | Every request is checked server-side: DMs require a real two-way friendship, rooms require membership, history is public-room only. IDs are random UUIDs. |
| Bad input / deserialisation | JSON only, 20 KB body limit, every field type- and length-checked; oversized socket frames drop the connection. |
| SQL injection | Not applicable: there is no SQL database. |
| Prompt injection | Not applicable: there is no AI in the app. |
| Files on the Pi | Data folder and files are created owner-only (700/600). |
| Dependencies | Native `bcrypt` (and its vulnerable `tar` installer chain) and `uuid` removed; `npm audit --omit=dev` is clean. |

Not built yet: two-factor sign-in (authenticator codes).

**Harden the Pi too** (outside this app): use SSH keys and turn off SSH password login, keep `sudo apt update && sudo apt upgrade` running, and in Cloudflare turn on *Always Use HTTPS* and *HSTS*.

## "Not Secure" in the address bar, or New room does nothing

You opened the site over plain `http://` (for example `http://192.168.0.30:3000`). Browsers switch off the encryption engine on insecure pages, so private rooms, friend chats and Link can't work there; the app now says so and links to `PUBLIC_URL`.

Use **https://zentencrypted.org**, at home too. If it won't load on your home Wi-Fi, your Pi-hole isn't resolving the domain: in Pi-hole go to *Settings → DNS*, tick Cloudflare (1.1.1.1) or Google as upstream, save, and run `sudo pihole reloaddns` on the Pi-hole. Once https works at home, set `HOST=127.0.0.1` so the http address stops working entirely.

## Customising

- **Icon:** replace the files in `public/icons/` (`icon-192.png`, `icon-512.png`, `apple-touch-icon.png`, `favicon-32.png`) plus `public/favicon.svg` and `public/favicon.ico`. The ones included are placeholders.
- **Themes:** Settings → Look. Seven built in, plus a custom builder. Themes can be shared as a short `ZT1.…` code.
- **Fonts:** Bricolage Grotesque and JetBrains Mono (SIL Open Font License, licences in `public/fonts/`).

## Tests

```bash
npm install          # (includes dev tools: jsdom, socket.io-client)
npm test
```

96 tests: friend messages (offline delivery, unread, keys, re-locking on password change), crypto (including man-in-the-middle detection), the human check, account security (password rules, per-account lockout, hash upgrades, sign-out-everywhere, CSRF), saved public history (including surviving a real restart and a hard kill), the cleanup tool, auth/cookies/rate limits, realtime rooms/expiry/DMs/abuse cases, and the real page driven in a simulated browser. It does **not** cover how the design looks or the peer-to-peer Link tab (both need a real browser).

## Layout

```
server.js            entry point
config/database.js   user store (lowdb)
src/                 auth, passwords, keys, rooms, realtime, friends, shield (human check), identity,
                     history (public room log), dmstore (encrypted friend messages)
scripts/             purge-public.js (owner's cleanup tool)
public/              the whole front end (no build step)
test/                the test suite
```

## License

MIT. Fonts under the SIL Open Font License. PeerJS under its own MIT licence.
