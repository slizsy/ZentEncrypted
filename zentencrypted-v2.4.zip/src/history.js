// Saved history for the public room: one JSON line per message, with retention and a size cap.
// Settings: PUBLIC_HISTORY, PUBLIC_HISTORY_DAYS (default 30, 0 = forever), PUBLIC_HISTORY_MAX.
const fs = require('fs');
const path = require('path');

const num = (v, d) => (Number.isFinite(Number(v)) && v !== undefined && v !== '' ? Number(v) : d);

function create(opts = {}) {
  const file = opts.file;
  const enabled = opts.enabled !== false;
  const days = Math.max(0, num(opts.days, 0));
  const max = Math.max(100, num(opts.max, 50000));

  let msgs = []; // ascending by n
  let seq = 0;
  let stream = null;
  let warned = false;

  const valid = (m) =>
    m && Number.isFinite(m.n) && Number.isFinite(m.ts) && typeof m.id === 'string' &&
    typeof m.sender === 'string' && typeof m.uid === 'string' && typeof m.text === 'string';

  function openStream() {
    if (!enabled) return;
    try {
      // Open the file synchronously so the stream is bound to *this* file right now.
      // (A lazily-opened stream could attach to a file we've since replaced and write duplicates.)
      const fd = fs.openSync(file, 'a');
      stream = fs.createWriteStream(file, { fd, autoClose: true });
      stream.on('error', (e) => {
        if (!warned) { warned = true; console.error('[history] write error on', file, '-', e.message); }
      });
    } catch (e) {
      stream = null;
      if (!warned) { warned = true; console.error('[history] could not open', file, '-', e.message, '(messages will not be saved)'); }
    }
  }

  /** Drops messages past the retention window or over the cap. Returns true if anything was removed. */
  function prune() {
    const before = msgs.length;
    if (days > 0) {
      const cutoff = Date.now() - days * 86400000;
      msgs = msgs.filter((m) => m.ts >= cutoff);
    }
    if (msgs.length > max) msgs = msgs.slice(msgs.length - max);
    return msgs.length !== before;
  }

  /** Atomically rewrites the file from memory (used after pruning/purging). */
  function rewrite() {
    if (!enabled) return;
    const old = stream;
    stream = null;
    if (old) old.end();
    const tmp = file + '.tmp';
    try {
      fs.writeFileSync(tmp, msgs.map((m) => JSON.stringify(m)).join('\n') + (msgs.length ? '\n' : ''));
      fs.renameSync(tmp, file);
    } catch (e) {
      if (!warned) { warned = true; console.error('[history] could not rewrite', file, '-', e.message); }
    }
    openStream();
  }

  function load() {
    if (!enabled) return { loaded: 0, skipped: 0 };
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true });
    } catch (e) {
      // Never let a storage problem take the chat down: keep history in memory only.
      warned = true;
      console.error('[history] cannot use', file, '-', e.message, '(history will be kept in memory only until this is fixed)');
    }
    let raw = '';
    try { raw = fs.readFileSync(file, 'utf8'); } catch { /* first run: no file yet */ }
    let skipped = 0;
    msgs = [];
    for (const line of raw.split('\n')) {
      if (!line.trim()) continue;
      try {
        const m = JSON.parse(line);
        if (valid(m)) msgs.push(m); else skipped++;
      } catch { skipped++; } // a half-written last line after a power cut, for example
    }
    msgs.sort((a, b) => a.n - b.n);
    seq = msgs.reduce((a, m) => Math.max(a, m.n), 0);
    if (prune() || skipped) rewrite(); else openStream();
    return { loaded: msgs.length, skipped };
  }

  function append({ id, ts, sender, uid, text }) {
    if (!enabled) return null;
    const rec = { n: ++seq, id, ts, sender, uid, text };
    msgs.push(rec);
    if (stream) stream.write(JSON.stringify(rec) + '\n');
    if (msgs.length > max + Math.ceil(max * 0.05)) { prune(); rewrite(); } // batch the trimming
    return rec;
  }

  /** Newest `limit` messages, or the `limit` just before message number `before`. */
  function page({ before, limit } = {}) {
    const lim = Math.min(100, Math.max(1, Math.floor(num(limit, 100))));
    let end = msgs.length;
    if (before !== undefined && before !== null && Number.isFinite(Number(before))) {
      const b = Number(before);
      let lo = 0, hi = msgs.length; // first index with n >= b
      while (lo < hi) { const mid = (lo + hi) >> 1; if (msgs[mid].n < b) lo = mid + 1; else hi = mid; }
      end = lo;
    }
    const start = Math.max(0, end - lim);
    return { messages: msgs.slice(start, end), hasMore: start > 0 };
  }

  /** For the cleanup script: removes matching messages and rewrites the file. Returns how many were removed. */
  function purge(predicate) {
    const before = msgs.length;
    msgs = msgs.filter((m) => !predicate(m));
    if (msgs.length !== before) rewrite();
    return before - msgs.length;
  }

  function close() {
    if (stream) { stream.end(); stream = null; }
  }

  const info = () => ({ enabled, days, max });
  const size = () => msgs.length;

  load();
  if (enabled && !opts.noSweep) setInterval(() => { if (prune()) rewrite(); }, 3600000).unref();

  return { append, page, purge, close, info, size, file };
}

// The server's store is created on first use, so tools that only want create()
// (like scripts/purge-public.js) don't open or trim the file as a side effect.
let shared = null;
function store() {
  if (!shared) {
    const dataDir = path.dirname(process.env.DB_FILE || path.join(__dirname, '..', 'data', 'db.json'));
    const days = process.env.PUBLIC_HISTORY_DAYS;
    shared = create({
      file: process.env.PUBLIC_HISTORY_FILE || path.join(dataDir, 'public-history.jsonl'),
      enabled: process.env.PUBLIC_HISTORY !== '0',
      days: days === undefined || days === '' ? 30 : days,
      max: process.env.PUBLIC_HISTORY_MAX,
    });
  }
  return shared;
}

module.exports = {
  create,
  append: (m) => store().append(m),
  page: (o) => store().page(o),
  purge: (fn) => store().purge(fn),
  info: () => store().info(),
  size: () => store().size(),
  close: () => { if (shared) shared.close(); },
};
