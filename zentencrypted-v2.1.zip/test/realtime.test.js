const test = require('node:test');
const assert = require('node:assert');
const { boot, client, connect, once, ack, sleep, fakeAuth, fakeLocator } = require('./helpers');

let srv, ipN = 0;
const nextIp = () => `10.20.${Math.floor(++ipN / 250)}.${(ipN % 250) + 1}`;
const sockets = [];

async function guest() {
  const ip = nextIp();
  const c = client(srv.base, ip);
  const r = await c.req('POST', '/api/auth/guest', {});
  assert.strictEqual(r.status, 200, 'guest sign-in failed: ' + r.status);
  const conn = await connect(srv.base, c.cookie, { headers: { 'cf-connecting-ip': ip } });
  sockets.push(conn.s);
  return { c, ...conn };
}
async function member(name) {
  const ip = nextIp();
  const c = client(srv.base, ip);
  const r = await c.req('POST', '/api/auth/register', { username: name, password: 'password-' + name });
  assert.strictEqual(r.status, 201, JSON.stringify(r.json));
  const conn = await connect(srv.base, c.cookie, { headers: { 'cf-connecting-ip': ip } });
  sockets.push(conn.s);
  return { c, ...conn, id: r.json.id, ip };
}

test.before(async () => { srv = await boot(); });
test.after(async () => { sockets.forEach((s) => s.close()); await srv.close(); });

test('sockets need a valid session; foreign Origin is refused', async () => {
  await assert.rejects(connect(srv.base, ''), /Unauthorized/);
  await assert.rejects(connect(srv.base, 'token=garbage'), /Unauthorized/);
  const c = client(srv.base, nextIp());
  await c.req('POST', '/api/auth/guest', {});
  await assert.rejects(connect(srv.base, c.cookie, { headers: { origin: 'https://evil.example' } }));
  const ok = await connect(srv.base, c.cookie, { headers: { origin: new URL(srv.base).origin } });
  sockets.push(ok.s);
  assert.ok(ok.me.uid && ok.me.room === 'public');
});

test('public room: plaintext relay to everyone, sender included, with stable uid; never needs a passphrase', async () => {
  const a = await guest(), b = await guest();
  const got = once(b.s, 'message:receive');
  const echo = once(a.s, 'message:receive');
  const res = await ack(a.s, 'message:send', { room: 'public', text: '  hello  <b>world</b>  ' });
  assert.strictEqual(res.ok, true);
  const m = await got;
  assert.strictEqual(m.text, 'hello  <b>world</b>');
  assert.strictEqual(m.sender, a.me.username);
  assert.strictEqual(m.uid, a.me.uid);
  assert.ok(m.id && m.ts);
  assert.strictEqual((await echo).id, m.id);
  assert.ok(!('ciphertext' in m));
});

test('public room: empty / oversized / wrong-shape / control-char messages are handled', async () => {
  const a = await guest();
  assert.strictEqual((await ack(a.s, 'message:send', { room: 'public', text: '   ' })).ok, false);
  assert.strictEqual((await ack(a.s, 'message:send', { room: 'public', text: 'x'.repeat(1001) })).ok, false);
  assert.strictEqual((await ack(a.s, 'message:send', { room: 'public', text: 42 })).ok, false);
  assert.strictEqual((await ack(a.s, 'message:send', { room: 'public', text: 'a'.repeat(5000) })).ok, false); // over app limit
  assert.strictEqual((await ack(a.s, 'message:send', null)).ok, false);
  assert.strictEqual((await ack(a.s, 'message:send', { room: 'public', ciphertext: 'x', iv: 'y' })).ok, false);
  await sleep(1100); // the flood limiter (5/s) counts rejected attempts too
  const got = once(a.s, 'message:receive');
  await ack(a.s, 'message:send', { room: 'public', text: 'a\u0000b\u202Ec' });
  assert.strictEqual((await got).text, 'abc');
  // missing ack callback must not crash the server
  a.s.emit('message:send', { room: 'public', text: 'no ack' });
  a.s.emit('room:join');
  await sleep(1100);
  assert.strictEqual((await ack(a.s, 'message:send', { room: 'public', text: 'still alive' })).ok, true);
});

test('a frame bigger than the hard cap drops the connection (DoS protection)', async () => {
  const a = await guest();
  const closed = new Promise((r) => a.s.once('disconnect', r));
  a.s.emit('message:send', { room: 'public', text: 'a'.repeat(40000) });
  await Promise.race([closed, sleep(3000).then(() => { throw new Error('socket was not dropped'); })]);
});

test('flooding: more than 5 messages/second is refused', async () => {
  const a = await guest();
  const results = [];
  for (let i = 0; i < 12; i++) results.push((await ack(a.s, 'message:send', { room: 'public', text: 'spam ' + i })).ok);
  assert.ok(results.filter(Boolean).length <= 6, JSON.stringify(results));
  assert.ok(results.includes(false));
});

test('cannot post into a room you have not joined (old bug: any socket could)', async () => {
  const a = await guest(), outsider = await guest();
  const locator = fakeLocator();
  const made = await ack(a.s, 'room:create', { name: 'Secret', locator, auth: fakeAuth(), ttlMs: 60000 });
  assert.strictEqual(made.ok, true);
  const r = await ack(outsider.s, 'message:send', { room: made.room.key, ciphertext: 'abc', iv: 'def' });
  assert.strictEqual(r.ok, false);
  assert.match(r.error, /Join/);
});

test('join-code room: create, join with right code, wrong code gets a generic error, ciphertext relays', async () => {
  const a = await guest(), b = await guest(), c = await guest();
  const locator = fakeLocator(), auth = fakeAuth();
  const made = await ack(a.s, 'room:create', { name: '  Study\u0000 group  ', locator, auth, ttlMs: 60000 });
  assert.strictEqual(made.ok, true);
  assert.strictEqual(made.room.name, 'Study group');
  assert.strictEqual(made.room.key, 'c:' + locator);
  assert.ok(made.room.expiresAt > Date.now());

  const bad = await ack(b.s, 'room:join', { locator, auth: fakeAuth() });
  const missing = await ack(b.s, 'room:join', { locator: 'ZZZZ', auth: fakeAuth() });
  assert.strictEqual(bad.ok, false);
  assert.strictEqual(bad.error, missing.error, 'wrong code and unknown room must look identical');
  assert.strictEqual((await ack(b.s, 'room:join', { locator: 'bad!', auth: 'nope' })).ok, false);
  assert.strictEqual((await ack(b.s, 'room:join', { locator })).ok, false);

  const good = await ack(b.s, 'room:join', { locator, auth });
  assert.strictEqual(good.ok, true);
  assert.strictEqual(good.room.count, 2);

  const got = once(b.s, 'message:receive');
  assert.strictEqual((await ack(a.s, 'message:send', { room: made.room.key, ciphertext: 'Zm9v', iv: 'YmFy' })).ok, true);
  const m = await got;
  assert.strictEqual(m.ciphertext, 'Zm9v');
  assert.ok(!('text' in m));

  // c never joined => hears nothing, and can't send
  let heard = false;
  c.s.once('message:receive', () => (heard = true));
  await ack(a.s, 'message:send', { room: made.room.key, ciphertext: 'a', iv: 'b' });
  await sleep(150);
  assert.strictEqual(heard, false);
});

test('join-code room: a room locks after repeated wrong guesses', async () => {
  const owner = await guest();
  const locator = fakeLocator(), auth = fakeAuth();
  await ack(owner.s, 'room:create', { name: 'Locked', locator, auth, ttlMs: 60000 });
  for (let i = 0; i < 4; i++) { // spread attempts over several sockets so the per-socket cap doesn't hide the room lock
    const g = await guest();
    for (let k = 0; k < 6; k++) await ack(g.s, 'room:join', { locator, auth: fakeAuth() });
  }
  const late = await guest();
  const r = await ack(late.s, 'room:join', { locator, auth });
  assert.strictEqual(r.ok, false, 'even the RIGHT code is refused while locked');
  assert.match(r.error, /locked/i);
});

test('per-socket wrong-code guessing is capped', async () => {
  const g = await guest();
  let last;
  for (let i = 0; i < 12; i++) last = await ack(g.s, 'room:join', { locator: fakeLocator(), auth: fakeAuth() });
  assert.match(last.error, /Too many/);
});

test('rooms burn at their deadline: everyone is told, room is gone, code no longer works', async () => {
  const a = await guest(), b = await guest();
  const locator = fakeLocator(), auth = fakeAuth();
  const made = await ack(a.s, 'room:create', { name: 'Short lived', locator, auth, ttlMs: 1000 }); // server min is 1000ms in tests
  await ack(b.s, 'room:join', { locator, auth });
  const expA = once(a.s, 'room:expired', 4000);
  const expB = once(b.s, 'room:expired', 4000);
  const ea = await expA, eb = await expB;
  assert.strictEqual(ea.room, made.room.key);
  assert.strictEqual(eb.reason, 'expired');
  const late = await guest();
  assert.strictEqual((await ack(late.s, 'room:join', { locator, auth })).ok, false);
  assert.strictEqual((await ack(a.s, 'message:send', { room: made.room.key, ciphertext: 'a', iv: 'b' })).ok, false);
});

test('TTL is clamped to the server min/max', async () => {
  const a = await guest();
  const lo = await ack(a.s, 'room:create', { name: 'lo', locator: fakeLocator(), auth: fakeAuth(), ttlMs: 1 });
  assert.ok(lo.room.expiresAt - Date.now() >= 900);
  const hi = await ack(a.s, 'room:create', { name: 'hi', locator: fakeLocator(), auth: fakeAuth(), ttlMs: 1e15 });
  assert.ok(hi.room.expiresAt - Date.now() <= 7 * 24 * 3600 * 1000 + 1000);
  const nan = await ack(a.s, 'room:create', { name: 'nan', locator: fakeLocator(), auth: fakeAuth(), ttlMs: 'soon' });
  assert.strictEqual(nan.ok, true);
});

test('burn-when-empty: the room disappears after everyone leaves', async () => {
  const a = await guest(), watcher = await guest();
  const locator = fakeLocator(), auth = fakeAuth();
  await ack(a.s, 'room:create', { name: 'Burner', locator, auth, ttlMs: 600000, burnWhenEmpty: true });
  a.s.disconnect();
  await sleep(900); // grace 300ms + sweep 150ms
  assert.strictEqual((await ack(watcher.s, 'room:join', { locator, auth })).ok, false);
});

test('a normal room survives its owner leaving (until its timer ends)', async () => {
  const a = await guest(), b = await guest();
  const locator = fakeLocator(), auth = fakeAuth();
  await ack(a.s, 'room:create', { name: 'Persist', locator, auth, ttlMs: 600000 });
  a.s.disconnect();
  await sleep(700);
  assert.strictEqual((await ack(b.s, 'room:join', { locator, auth })).ok, true);
});

test('room creation validation + per-user cap + duplicate locator', async () => {
  const a = await guest();
  const mk = (over = {}) => ack(a.s, 'room:create', { name: 'r', locator: fakeLocator(), auth: fakeAuth(), ttlMs: 60000, ...over });
  assert.strictEqual((await mk({ name: '   ' })).ok, false);
  assert.strictEqual((await mk({ auth: 'short' })).ok, false);
  assert.strictEqual((await mk({ locator: 'abcd' })).ok, false);
  assert.strictEqual((await mk({ locator: 'OOOO' })).ok, false);
  const loc = fakeLocator();
  assert.strictEqual((await mk({ locator: loc })).ok, true);
  assert.strictEqual((await mk({ locator: loc })).error, 'taken');
  for (let i = 0; i < 3; i++) assert.strictEqual((await mk()).ok, true);
  const fifth = await mk();
  assert.strictEqual(fifth.ok, true);
  const sixth = await mk();
  assert.strictEqual(sixth.ok, false);
  assert.match(sixth.error, /5 active rooms|too fast/);
});

test('friends: add by code => both notified live; DM needs real friendship; key relay; one tab per DM; unfriend kicks', async () => {
  const a = await member('dmAlice'), b = await member('dmBob'), eve = await member('dmEve');
  const bCode = (await b.c.req('GET', '/api/friends/me')).json.friendCode;

  // Not friends yet => cannot open a DM, even by guessing the room name
  const room = [a.id, b.id].sort();
  const key = `dm:${room[0]}:${room[1]}`;
  assert.strictEqual((await ack(a.s, 'room:join', { room: key })).ok, false);

  const notifyA = once(a.s, 'friends:changed'), notifyB = once(b.s, 'friends:changed');
  const add = await a.c.req('POST', '/api/friends/add', { code: bCode });
  assert.strictEqual(add.status, 201);
  assert.strictEqual(add.json.friend.room, key);
  await notifyA; await notifyB;

  // Eve cannot join Alice+Bob's DM
  assert.strictEqual((await ack(eve.s, 'room:join', { room: key })).ok, false);
  // Nor a fabricated / malformed DM name
  assert.strictEqual((await ack(a.s, 'room:join', { room: 'dm:not:uuids' })).ok, false);
  assert.strictEqual((await ack(a.s, 'room:join', { room: `dm:${a.id}:${eve.id}` })).ok, false);

  const ja = await ack(a.s, 'room:join', { room: key });
  assert.strictEqual(ja.ok, true);
  assert.strictEqual(ja.peerOnline, true);
  const jb = await ack(b.s, 'room:join', { room: key });
  assert.strictEqual(jb.ok, true);

  // public-key relay: hello goes to the *other* side only
  const gotHello = once(b.s, 'dm:key');
  let selfEcho = false;
  a.s.once('dm:key', () => (selfEcho = true));
  a.s.emit('dm:key', { room: key, pub: 'QUJD', kind: 'hello' });
  const h = await gotHello;
  assert.strictEqual(h.pub, 'QUJD'); assert.strictEqual(h.kind, 'hello'); assert.strictEqual(h.from, a.me.uid);
  await sleep(100);
  assert.strictEqual(selfEcho, false);
  // junk key exchange messages are dropped
  let junk = false;
  b.s.once('dm:key', () => (junk = true));
  a.s.emit('dm:key', { room: key, pub: '<script>', kind: 'hello' });
  a.s.emit('dm:key', { room: key, pub: 'QUJD', kind: 'evil' });
  a.s.emit('dm:key', { room: 'public', pub: 'QUJD', kind: 'hello' });
  eve.s.emit('dm:key', { room: key, pub: 'QUJD', kind: 'hello' });
  await sleep(150);
  assert.strictEqual(junk, false);

  // ciphertext flows in the DM
  const gotMsg = once(b.s, 'message:receive');
  await ack(a.s, 'message:send', { room: key, ciphertext: 'c2VhbGVk', iv: 'aXY=' });
  assert.strictEqual((await gotMsg).ciphertext, 'c2VhbGVk');

  // second tab of Alice takes over the DM; the first is told
  const a2conn = await connect(srv.base, a.c.cookie, { headers: { 'cf-connecting-ip': a.ip } }); sockets.push(a2conn.s);
  const kicked = once(a.s, 'room:kicked');
  assert.strictEqual((await ack(a2conn.s, 'room:join', { room: key })).ok, true);
  assert.match((await kicked).reason, /another tab/);
  assert.strictEqual((await ack(a.s, 'message:send', { room: key, ciphertext: 'x', iv: 'y' })).ok, false);

  // unfriend: Bob is kicked from the DM and cannot come back
  const bKicked = once(b.s, 'room:kicked');
  const del = await a.c.req('DELETE', `/api/friends/${b.id}`);
  assert.strictEqual(del.status, 200);
  assert.match((await bKicked).reason, /removed/);
  assert.strictEqual((await ack(b.s, 'room:join', { room: key })).ok, false);
  assert.strictEqual((await ack(a2conn.s, 'room:join', { room: key })).ok, false);
});

test('DM ring: a friend is told when someone opens a chat with them (once, and not if already inside)', async () => {
  const a = await member('ringA'), b = await member('ringB');
  await a.c.req('POST', '/api/friends/add', { code: (await b.c.req('GET', '/api/friends/me')).json.friendCode });
  const ids = [a.id, b.id].sort();
  const key = `dm:${ids[0]}:${ids[1]}`;
  const ring = once(b.s, 'dm:ring');
  await ack(a.s, 'room:join', { room: key });
  const r = await ring;
  assert.strictEqual(r.room, key);
  assert.strictEqual(r.username, 'ringA');
  // B is now inside; if A reconnects/rejoins, B must not be rung again
  await ack(b.s, 'room:join', { room: key });
  let again = false;
  b.s.once('dm:ring', () => (again = true));
  await ack(a.s, 'room:join', { room: key });
  await sleep(150);
  assert.strictEqual(again, false);
});

test('friend presence: online/offline pushed to friends; friends:online lists who is up', async () => {
  const a = await member('presA'), b = await member('presB');
  await a.c.req('POST', '/api/friends/add', { code: (await b.c.req('GET', '/api/friends/me')).json.friendCode });
  const who = await ack(a.s, 'friends:online', {});
  assert.deepStrictEqual(who.online, [b.id]);
  const offline = once(a.s, 'friend:presence');
  b.s.disconnect();
  const p = await offline;
  assert.deepStrictEqual(p, { id: b.id, online: false });
  const b2c = client(srv.base, nextIp());
  await b2c.req('POST', '/api/auth/login', { username: 'presB', password: 'password-presB' });
  const online = once(a.s, 'friend:presence');
  const b2 = await connect(srv.base, b2c.cookie, { headers: { 'cf-connecting-ip': b.ip } }); sockets.push(b2.s);
  assert.deepStrictEqual(await online, { id: b.id, online: true });
});

test('guests and members can be friends; guest friendship is in memory only', async () => {
  const g = await guest(), m = await member('memFriend');
  const code = (await m.c.req('GET', '/api/friends/me')).json.friendCode;
  const r = await g.c.req('POST', '/api/friends/add', { code });
  assert.strictEqual(r.status, 201);
  const list = await m.c.req('GET', '/api/friends/list');
  assert.strictEqual(list.json.friends[0].username, g.me.username);
  assert.strictEqual(list.json.friends[0].role, 'guest');
});

test('presence + counts: joining/leaving announces and counts update', async () => {
  const a = await guest();
  const joined = once(a.s, 'room:count');
  const b = await guest();
  const cnt = await joined;
  assert.strictEqual(cnt.room, 'public');
  assert.ok(cnt.count >= 2);
  const left = once(a.s, 'presence:leave');
  b.s.disconnect();
  assert.strictEqual((await left).uid, b.me.uid);
});

test('typing is only relayed to members of that room', async () => {
  const a = await guest(), b = await guest();
  const t = once(b.s, 'typing');
  a.s.emit('typing', { room: 'public' });
  assert.strictEqual((await t).uid, a.me.uid);
  let leaked = false;
  b.s.once('typing', () => (leaked = true));
  a.s.emit('typing', { room: 'c:ZZZZ' });
  await sleep(150);
  assert.strictEqual(leaked, false);
});

test('server never stores message content: nothing on disk mentions it', async () => {
  const fs = require('fs');
  const a = await guest();
  const marker = 'UNIQUE-MARKER-' + Date.now();
  await ack(a.s, 'message:send', { room: 'public', text: marker });
  await sleep(100);
  assert.ok(!fs.readFileSync(process.env.DB_FILE, 'utf8').includes(marker));
});

test('connection flood guard still works (small cap): extra sockets from one network get a clear connect_error', async () => {
  const shield = require('../src/shield');
  const key = 'flood-test-net';
  const opened = [];
  for (let i = 0; i < 400; i++) { if (shield.connOpen(key)) opened.push(i); else break; }
  assert.ok(opened.length >= 200 && opened.length <= 500, 'cap should be a few hundred, got ' + opened.length);
  assert.strictEqual(shield.connOpen(key), false);
  for (let i = 0; i < opened.length; i++) shield.connClose(key);
});
