/**
 * Drives the REAL page (index.html + all scripts) in jsdom against the REAL
 * server, clicking and typing like a person. Crypto, sockets, cookies and the
 * human-check hooks are all genuine; only the browser shell is simulated.
 */
const test = require('node:test');
const assert = require('node:assert');
const { webcrypto } = require('node:crypto');
const { JSDOM, CookieJar, VirtualConsole } = require('jsdom');
const { boot, sleep } = require('./helpers');

let srv, ipCounter = 0;
const doms = [];
const pageErrors = [];

async function openClient(label) {
  const ip = `10.55.${Math.floor(++ipCounter / 250)}.${(ipCounter % 250) + 1}`;
  const jar = new CookieJar();
  const vc = new VirtualConsole();
  vc.on('jsdomError', (e) => pageErrors.push(`[${label}] ${e.message}`));
  vc.on('error', (...a) => pageErrors.push(`[${label}] console.error: ${a.join(' ').slice(0, 300)}`));

  const dom = await JSDOM.fromURL(srv.base + '/', {
    runScripts: 'dangerously',
    resources: 'usable',
    pretendToBeVisual: true,
    cookieJar: jar,
    virtualConsole: vc,
    beforeParse(window) {
      Object.defineProperty(window, 'crypto', { value: webcrypto, configurable: true });
      window.TextEncoder = TextEncoder;
      window.TextDecoder = TextDecoder;
      window.matchMedia = (q) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {} });
      window.AudioContext = undefined;
      window.fetch = async (url, opts = {}) => {
        const full = new URL(url, srv.base).href;
        const headers = { ...(opts.headers || {}), 'cf-connecting-ip': ip };
        const cookie = jar.getCookieStringSync(full);
        if (cookie) headers.cookie = cookie;
        const res = await fetch(full, { method: opts.method || 'GET', headers, body: opts.body });
        for (const c of res.headers.getSetCookie()) jar.setCookieSync(c, full);
        return res;
      };
      window.sessionStorage.setItem('zent_booted', '1'); // skip the intro animation
      window.addEventListener('error', (e) => pageErrors.push(`[${label}] window.onerror: ${e.message}`));
      window.addEventListener('unhandledrejection', (e) => pageErrors.push(`[${label}] unhandled rejection: ${e.reason && e.reason.message}`));
    },
  });
  doms.push(dom);
  const { window } = dom;
  const { document } = window;
  const $ = (id) => document.getElementById(id);
  // fromURL resolves before the external scripts have run; a real person can't click that early either
  for (let i = 0; i < 400 && document.readyState !== 'complete'; i++) await sleep(25);
  await sleep(120); // let the first /api/auth/me round-trip settle

  const api = {
    window, document, $, jar,
    async waitFor(fn, what = 'condition', ms = 6000) {
      const t0 = Date.now();
      for (;;) {
        let v;
        try { v = fn(); } catch { v = false; }
        if (v) return v;
        if (Date.now() - t0 > ms) throw new Error(`[${label}] timed out waiting for ${what}`);
        await sleep(25);
      }
    },
    type(el, value) {
      el.value = value;
      el.dispatchEvent(new window.Event('input', { bubbles: true }));
      el.dispatchEvent(new window.Event('change', { bubbles: true }));
    },
    click: (el) => el.click(),
    visible: (el) => !el.classList.contains('is-hidden'),
    messages: () => Array.from(document.querySelectorAll('.log.is-visible .msg-body')).map((n) => n.textContent),
    allMessages: (key) => Array.from(document.querySelectorAll(`.log[data-room="${key}"] .msg-body`)).map((n) => n.textContent),
    async guest() {
      await api.waitFor(() => api.visible($('auth-screen')), 'auth screen');
      api.click($('guest-btn'));
      await api.waitFor(() => api.visible($('app')) && $('signal').dataset.state === 'up', 'app + connection');
      await api.waitFor(() => !$('composer-input').disabled, 'composer enabled');
    },
    async register(name, pass) {
      await api.waitFor(() => api.visible($('auth-screen')), 'auth screen');
      api.click($('tab-register'));
      api.type($('register-username'), name);
      api.type($('register-password'), pass);
      api.click($('register-form').querySelector('button[type=submit]'));
      await api.waitFor(() => api.visible($('app')) && $('signal').dataset.state === 'up', 'registered + connected');
      await api.waitFor(() => !$('composer-input').disabled, 'composer enabled');
    },
    async say(text) {
      api.type($('composer-input'), text);
      $('composer').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
    },
  };
  return api;
}

test.before(async () => { srv = await boot({ SHIELD_AUTH_SOFT: '100' }); });
test.after(async () => { doms.forEach((d) => d.window.close()); await srv.close(); });

test('page loads clean: no script errors, sign-in screen shown, app hidden, icons/manifest linked', async () => {
  const a = await openClient('load');
  await a.waitFor(() => a.visible(a.$('auth-screen')), 'auth screen');
  assert.ok(a.$('app').classList.contains('is-hidden'));
  assert.strictEqual(a.document.querySelector('link[rel=manifest]').getAttribute('href'), '/manifest.webmanifest');
  assert.ok(a.document.querySelector('link[rel=apple-touch-icon]'));
  assert.ok(a.document.querySelector('link[rel=icon][type="image/svg+xml"]'));
  assert.deepStrictEqual(pageErrors, []);
});

test('guest sign-in: lands in #public with no passphrase prompt, can chat, message shows as "you"', async () => {
  const a = await openClient('guest');
  await a.guest();
  assert.match(a.$('me-name').textContent, /^Guest\d{4}$/);
  assert.strictEqual(a.$('room-title').textContent, 'public');
  assert.strictEqual(a.$('mode-stamp').textContent, 'OPEN');
  assert.ok(a.$('composer-input').placeholder.includes('everyone can read it'));
  await a.say('hello <b>world</b> & friends');
  await a.waitFor(() => a.messages().length === 1, 'own message echo');
  assert.strictEqual(a.messages()[0], 'hello <b>world</b> & friends'); // shown as text, never as markup
  assert.strictEqual(a.document.querySelector('.log.is-visible .msg b'), null, 'no injected elements');
  assert.ok(a.document.querySelector('.log.is-visible .msg.is-own'));
  assert.strictEqual(a.document.querySelector('.log.is-visible .msg-who').textContent, 'you');
  assert.strictEqual(a.$('composer-input').value, '');
  assert.deepStrictEqual(pageErrors, []);
});

test('two people in #public see each other; messages while you are elsewhere raise an unread badge and the tab title', async () => {
  const a = await openClient('pubA'), b = await openClient('pubB');
  await a.guest(); await b.guest();
  await a.say('hi from A');
  await b.waitFor(() => b.messages().includes('hi from A'), 'B receives A');
  assert.match(b.document.querySelector('.log.is-visible .msg:not(.is-own) .msg-who').textContent, /^Guest\d{4}$/);
  assert.ok(!b.visible(b.$('rooms-badge')), 'no badge while B is looking at public');

  // B wanders off to a room of their own, then A talks in public
  b.click(b.$('open-create'));
  b.type(b.$('cr-name'), 'Elsewhere');
  b.$('cr-form').dispatchEvent(new b.window.Event('submit', { bubbles: true, cancelable: true }));
  await b.waitFor(() => b.visible(b.$('cr-result')), 'B created');
  b.click(b.$('cr-open'));
  await b.waitFor(() => b.$('room-title').textContent === 'Elsewhere', 'B moved');
  await sleep(1100); // stay under the 5 msg/s limiter
  await a.say('are you there?');
  await b.waitFor(() => b.visible(b.$('rooms-badge')) && b.$('rooms-badge').textContent === '1', 'unread badge');
  assert.match(b.document.title, /^\(1\) ZENT/);
  b.click(b.document.querySelector('#room-list .item')); // public is first
  await b.waitFor(() => b.$('room-title').textContent === 'public', 'back to public');
  assert.ok(!b.visible(b.$('rooms-badge')), 'badge cleared');
  assert.ok(b.messages().includes('are you there?'));
  assert.doesNotMatch(b.document.title, /^\(/);
  assert.deepStrictEqual(pageErrors, []);
});

test('create a room: join code shown, room listed with a countdown; second person joins by typing the code; messages are encrypted end-to-end', async () => {
  const a = await openClient('roomA'), b = await openClient('roomB');
  await a.guest(); await b.guest();

  // --- A creates a 1-hour room
  a.click(a.$('open-create'));
  assert.ok(a.$('dlg-create').classList.contains('is-open'));
  a.type(a.$('cr-name'), 'Study group');
  a.type(a.$('cr-ttl'), '3600000');
  a.$('cr-form').dispatchEvent(new a.window.Event('submit', { bubbles: true, cancelable: true }));
  await a.waitFor(() => a.visible(a.$('cr-result')), 'result view');
  const code = a.$('cr-code').textContent;
  assert.match(code, /^[A-HJ-NP-Z2-9]{4}(-[A-HJ-NP-Z2-9]{4}){3}$/);
  a.click(a.$('cr-open'));
  await a.waitFor(() => a.$('room-title').textContent === 'Study group', 'room open');
  assert.strictEqual(a.$('mode-stamp').textContent, 'SEALED');
  assert.ok(a.visible(a.$('expiry-pill')));
  assert.match(a.$('expiry-text').textContent, /^00:(59|60|58):\d\d$|^01:00:00$/);
  assert.ok(a.visible(a.$('room-share')));

  // --- B tries a wrong code first, then the real one
  b.click(b.$('open-join'));
  b.type(b.$('jn-code'), 'AAAA-BBBB-CCCC-DDDD');
  b.$('jn-form').dispatchEvent(new b.window.Event('submit', { bubbles: true, cancelable: true }));
  await b.waitFor(() => b.visible(b.$('jn-error')), 'wrong-code error');
  assert.match(b.$('jn-error').textContent, /didn't work/);
  b.type(b.$('jn-code'), code.toLowerCase().replace(/-/g, ' '));
  b.$('jn-form').dispatchEvent(new b.window.Event('submit', { bubbles: true, cancelable: true }));
  await b.waitFor(() => b.$('room-title').textContent === 'Study group', 'B joined');

  // --- encrypted both ways
  await a.say('the answer is 42');
  await b.waitFor(() => b.messages().includes('the answer is 42'), 'B decrypts A');
  await b.say('thanks!');
  await a.waitFor(() => a.messages().includes('thanks!'), 'A decrypts B');

  // --- the server never saw plaintext: verify by sniffing what the room relayed
  const ioSockets = Array.from(srv.server.listeners('request')).length; // sanity: server alive
  assert.ok(ioSockets >= 1);
  assert.deepStrictEqual(pageErrors, []);
});

test('invite link opens the join dialog pre-filled and scrubs the code from the address bar', async () => {
  const a = await openClient('linkA');
  await a.guest();
  a.click(a.$('open-create'));
  a.type(a.$('cr-name'), 'Invite me');
  a.$('cr-form').dispatchEvent(new a.window.Event('submit', { bubbles: true, cancelable: true }));
  await a.waitFor(() => a.visible(a.$('cr-result')), 'created');
  const code = a.$('cr-code').textContent;

  // a new visitor opens /#join=CODE
  const jar = new CookieJar();
  const c = await (async () => {
    const dom = await JSDOM.fromURL(`${srv.base}/#join=${code}`, {
      runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, cookieJar: jar,
      beforeParse(window) {
        Object.defineProperty(window, 'crypto', { value: webcrypto, configurable: true });
        window.TextEncoder = TextEncoder; window.TextDecoder = TextDecoder;
        window.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {} });
        window.fetch = async (url, o = {}) => {
          const full = new URL(url, srv.base).href;
          const headers = { ...(o.headers || {}), 'cf-connecting-ip': '10.99.0.1' };
          const ck = jar.getCookieStringSync(full); if (ck) headers.cookie = ck;
          const r = await fetch(full, { method: o.method || 'GET', headers, body: o.body });
          for (const s of r.headers.getSetCookie()) jar.setCookieSync(s, full);
          return r;
        };
        window.sessionStorage.setItem('zent_booted', '1');
      },
    });
    doms.push(dom);
    for (let i = 0; i < 400 && dom.window.document.readyState !== 'complete'; i++) await sleep(25);
    await sleep(120);
    return dom;
  })();
  const d = c.window.document;
  const el = (id) => d.getElementById(id);
  const until = async (fn, what) => { const t = Date.now(); while (!fn()) { if (Date.now() - t > 6000) throw new Error('timeout ' + what); await sleep(25); } };
  await until(() => !el('auth-screen').classList.contains('is-hidden'), 'auth');
  el('guest-btn').click();
  await until(() => el('dlg-join').classList.contains('is-open'), 'join dialog');
  assert.strictEqual(el('jn-code').value, code);
  assert.strictEqual(c.window.location.hash, '', 'code scrubbed from the URL');
});

test('friends: register two members, add by code, DM with zero typing of passwords, safety codes match, encrypted both ways', async () => {
  const a = await openClient('frA'), b = await openClient('frB');
  await a.register('frienda', 'password-a-123');
  await b.register('friendb', 'password-b-123');

  // B shows A their code
  b.click(b.document.querySelector('.tab[data-tab="friends"]'));
  await b.waitFor(() => /^[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$/.test(b.$('friend-code-text').textContent), 'B code');
  const bCode = b.$('friend-code-text').textContent;

  a.click(a.document.querySelector('.tab[data-tab="friends"]'));
  a.type(a.$('add-friend-input'), bCode);
  a.$('add-friend-form').dispatchEvent(new a.window.Event('submit', { bubbles: true, cancelable: true }));
  await a.waitFor(() => a.document.querySelectorAll('#friend-list .item').length === 1, 'A sees B');
  await b.waitFor(() => b.document.querySelectorAll('#friend-list .item').length === 1, 'B sees A (live)');
  assert.ok(a.visible(a.$('friends-empty')) === false);
  await a.waitFor(() => a.document.querySelector('#friend-list .dot.is-on'), 'B shows online');

  // A opens the DM. B gets a "ring", opens it, keys agree automatically.
  a.click(a.document.querySelector('#friend-list .item'));
  await a.waitFor(() => a.$('room-title').textContent === 'friendb', 'A in DM');
  await b.waitFor(() => /wants to chat/.test(b.document.querySelector('#friend-list .item-sub').textContent), 'B rung');
  assert.ok(b.visible(b.$('friends-badge')));
  assert.ok(a.$('composer-input').disabled, 'cannot send until the friend is there (nothing is stored)');

  b.click(b.document.querySelector('#friend-list .item'));
  await b.waitFor(() => b.$('room-title').textContent === 'frienda', 'B in DM');
  await a.waitFor(() => !a.$('composer-input').disabled, 'A unlocked');
  await b.waitFor(() => !b.$('composer-input').disabled, 'B unlocked');
  assert.strictEqual(a.$('mode-stamp').textContent, 'SEALED');
  const sa = a.$('mode-text').textContent.match(/SAFETY CODE ([0-9A-F]{4}-[0-9A-F]{4})/)[1];
  const sb = b.$('mode-text').textContent.match(/SAFETY CODE ([0-9A-F]{4}-[0-9A-F]{4})/)[1];
  assert.strictEqual(sa, sb, 'both friends see the same safety code');

  await a.say('psst, private');
  await b.waitFor(() => b.messages().includes('psst, private'), 'B decrypts DM');
  await b.say('got it');
  await a.waitFor(() => a.messages().includes('got it'), 'A decrypts DM');

  // unfriend from A's side kicks B out of the DM
  a.click(a.document.querySelector('#friend-list .item-x'));
  await a.waitFor(() => a.$('dlg-confirm').classList.contains('is-open'), 'confirm dialog');
  a.click(a.$('cf-ok'));
  await a.waitFor(() => a.document.querySelectorAll('#friend-list .item').length === 0, 'A list empty');
  await b.waitFor(() => b.document.querySelectorAll('#friend-list .item').length === 0, 'B list empty');
  await b.waitFor(() => b.$('room-title').textContent === 'public', 'B bounced back to public');
  assert.deepStrictEqual(pageErrors, []);
});

test('rooms burn: when the server says time is up, the UI toasts, removes the room, and drops you back to #public', async () => {
  const a = await openClient('burnA');
  await a.guest();
  a.click(a.$('open-create'));
  a.type(a.$('cr-name'), 'Doomed');
  a.$('cr-form').dispatchEvent(new a.window.Event('submit', { bubbles: true, cancelable: true }));
  await a.waitFor(() => a.visible(a.$('cr-result')), 'created');
  a.click(a.$('cr-open'));
  await a.waitFor(() => a.$('room-title').textContent === 'Doomed', 'inside');
  assert.strictEqual(a.document.querySelectorAll('#room-list .item').length, 2);
  assert.ok(a.window.localStorage.getItem('zent_rooms'), 'remembered on this device');

  // the server-side timer is covered in realtime.test.js; here we check what the page does with the event
  const key = 'c:' + a.$('cr-code').textContent.slice(0, 4);
  srv.io.to(key).emit('room:expired', { room: key, name: 'Doomed', reason: 'expired' });
  await a.waitFor(() => /Doomed.*burned/.test(a.document.querySelector('.toast').textContent), 'toast');
  await a.waitFor(() => a.document.querySelectorAll('#room-list .item').length === 1, 'room removed from list', 4000);
  await a.waitFor(() => a.$('room-title').textContent === 'public', 'back in public', 4000);
  assert.strictEqual(a.window.localStorage.getItem('zent_rooms'), null, 'no longer remembered');
  assert.ok(!a.document.querySelector('[data-room="' + key + '"]'), 'its message log is gone');
  assert.deepStrictEqual(pageErrors, []);
});

test('settings: themes switch, custom theme round-trips through a share code, toggles persist', async () => {
  const a = await openClient('settings');
  await a.guest();
  a.click(a.$('open-settings'));
  assert.ok(a.$('settings').classList.contains('is-open'));

  const swatches = a.document.querySelectorAll('#theme-grid .swatch');
  assert.strictEqual(swatches.length, 8, '7 presets + custom');
  const paper = Array.from(swatches).find((s) => /paper/i.test(s.textContent));
  a.click(paper);
  assert.strictEqual(a.document.documentElement.dataset.theme, 'paper');
  assert.strictEqual(a.document.documentElement.style.getPropertyValue('--bg').trim(), '#e9e2d0');
  assert.strictEqual(a.document.documentElement.style.colorScheme, 'light');
  const phos = Array.from(a.document.querySelectorAll('#theme-grid .swatch')).find((s) => /phosphor/i.test(s.textContent));
  a.click(phos);
  assert.strictEqual(a.document.documentElement.dataset.scan, '1');
  assert.strictEqual(a.document.documentElement.dataset.mono, '1');

  // custom theme: change accent, copy the code, load it in a fresh page
  a.type(a.$('ct-accent'), '#12ab34');
  assert.strictEqual(a.document.documentElement.dataset.theme, 'custom');
  assert.strictEqual(a.document.documentElement.style.getPropertyValue('--accent').trim(), '#12ab34');
  const { window } = a;
  const code = window.eval('Themes').exportCode(window.eval('Themes').getCustom());
  assert.match(code, /^ZT1\.[A-Za-z0-9_-]+$/);
  const b = await openClient('settings2');
  await b.guest();
  b.type(b.$('ct-code'), code);
  b.click(b.$('ct-import'));
  assert.strictEqual(b.document.documentElement.dataset.theme, 'custom');
  assert.strictEqual(b.$('ct-accent').value, '#12ab34');
  b.type(b.$('ct-code'), 'ZT1.not-a-real-code');
  b.click(b.$('ct-import'));
  assert.ok(b.document.querySelector('.toast.is-error'), 'bad code is rejected with a message');

  // settings persist in localStorage and survive a reload of the module
  a.$('set-compact').checked = true;
  a.$('set-compact').dispatchEvent(new a.window.Event('change', { bubbles: true }));
  assert.strictEqual(a.document.documentElement.dataset.compact, '1');
  assert.strictEqual(JSON.parse(a.window.localStorage.getItem('zent_settings_v2')).compact, true);
  assert.strictEqual(JSON.parse(a.window.localStorage.getItem('zent_settings_v2')).theme, 'custom');

  // translation toggle is disabled with an honest note where the browser lacks it
  assert.ok(a.$('set-translate').disabled);
  assert.match(a.$('translate-note').textContent, /no on-device translator/);
  assert.deepStrictEqual(pageErrors, []);
});

/** Opens the site in a brand-new tab: same cookies + saved settings, but no sessionStorage. */
async function openFreshTab(cookieHeader, settingsJson, label) {
  const jar = new CookieJar();
  jar.setCookieSync(cookieHeader.split(';')[0], srv.base + '/');
  const dom = await JSDOM.fromURL(srv.base + '/', {
    runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, cookieJar: jar,
    beforeParse(window) {
      Object.defineProperty(window, 'crypto', { value: webcrypto, configurable: true });
      window.TextEncoder = TextEncoder; window.TextDecoder = TextDecoder;
      window.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {} });
      window.localStorage.setItem('zent_settings_v2', settingsJson);
      window.sessionStorage.setItem('zent_booted', '1'); // skip the intro, but NOT zent_tab: that's what makes it a new tab
      window.fetch = async (url, o = {}) => {
        const full = new URL(url, srv.base).href;
        const headers = { ...(o.headers || {}), 'cf-connecting-ip': '10.98.' + label };
        const ck = jar.getCookieStringSync(full); if (ck) headers.cookie = ck;
        const r = await fetch(full, { method: o.method || 'GET', headers, body: o.body });
        for (const sc of r.headers.getSetCookie()) jar.setCookieSync(sc, full);
        return r;
      };
    },
  });
  doms.push(dom);
  for (let i = 0; i < 400 && dom.window.document.readyState !== 'complete'; i++) await sleep(25);
  const d = dom.window.document;
  const until = async (fn, what, ms = 6000) => { const t = Date.now(); while (!fn()) { if (Date.now() - t > ms) throw new Error('timeout: ' + what); await sleep(25); } };
  return { dom, jar, d, el: (id) => d.getElementById(id), until, hasSession: () => jar.getCookieStringSync(srv.base + '/').includes('token=') };
}

test('privacy: with "sign out when I close this tab" ON, a new tab is signed out (cookie really cleared); with it OFF the same cookie keeps you in', async () => {
  const a = await openClient('priv');
  await a.guest();
  const cookie = a.jar.getCookieStringSync(srv.base + '/');
  assert.ok(cookie.includes('token='));

  // control: setting OFF -> a new tab with the same cookie goes straight into the app
  const offSettings = JSON.stringify({ ...JSON.parse(a.window.localStorage.getItem('zent_settings_v2') || '{}'), wipeOnClose: false });
  const control = await openFreshTab(cookie, offSettings, '1.1');
  await control.until(() => !control.el('app').classList.contains('is-hidden'), 'control tab enters the app');
  assert.ok(control.hasSession(), 'control keeps its session');

  // setting ON -> a new tab is signed out for real
  a.$('set-wipe-close').checked = true;
  a.$('set-wipe-close').dispatchEvent(new a.window.Event('change', { bubbles: true }));
  const onSettings = a.window.localStorage.getItem('zent_settings_v2');
  assert.strictEqual(JSON.parse(onSettings).wipeOnClose, true);
  const fresh = await openFreshTab(cookie, onSettings, '1.2');
  await fresh.until(() => !fresh.hasSession(), 'session cookie cleared by the server');
  await sleep(300); // let the page finish its own startup
  assert.ok(!fresh.el('auth-screen').classList.contains('is-hidden'), 'sign-in screen shown');
  assert.ok(fresh.el('app').classList.contains('is-hidden'), 'app stays hidden');
  fresh.dom.window.close(); control.dom.window.close();
});
