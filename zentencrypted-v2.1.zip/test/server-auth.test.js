const test = require('node:test');
const assert = require('node:assert');
const { boot, client } = require('./helpers');
const { solve } = require('../public/js/pow-worker.js');

let srv;
test.before(async () => { srv = await boot(); });
test.after(async () => { await srv.close(); });

test('health + security headers (no HSTS, strict CSP, no upgrade-insecure-requests)', async () => {
  const r = await fetch(srv.base + '/health');
  assert.strictEqual((await r.json()).ok, true);
  assert.strictEqual(r.headers.get('strict-transport-security'), null);
  const csp = r.headers.get('content-security-policy');
  assert.ok(csp.includes("script-src 'self'") && csp.includes("style-src 'self'"));
  assert.ok(!csp.includes('unsafe-inline'));
  assert.ok(!csp.includes('upgrade-insecure-requests'));
  assert.ok(csp.includes("frame-ancestors 'none'"));
});

test('register validation: reserved names, bad chars, short passwords, non-strings', async () => {
  let n = 0;
  const post = (body) => client(srv.base, '10.0.0.' + (++n)).req('POST', '/api/auth/register', body); // fresh visitor each time
  for (const u of ['admin', 'System', 'guest1234', 'ab', 'bad name!', 'x'.repeat(21)]) {
    assert.strictEqual((await post({ username: u, password: 'longenough1' })).status, 400, u);
  }
  assert.strictEqual((await post({ username: 'okname', password: 'short' })).status, 400);
  assert.strictEqual((await post({ username: { $ne: 1 }, password: 'longenough1' })).status, 400);
  assert.strictEqual((await post({ username: 'okname', password: ['a'] })).status, 400);
});

test('register -> login -> me; duplicate names (any case) rejected; wrong password 401', async () => {
  const c = client(srv.base, '10.0.0.2');
  const r = await c.req('POST', '/api/auth/register', { username: 'Alice_1', password: 'correct horse' });
  assert.strictEqual(r.status, 201);
  assert.strictEqual((await c.req('GET', '/api/auth/me')).json.username, 'Alice_1');
  assert.strictEqual((await client(srv.base, '10.0.0.3').req('POST', '/api/auth/register', { username: 'alice_1', password: 'whatever12' })).status, 409);

  const c2 = client(srv.base, '10.0.0.4');
  assert.strictEqual((await c2.req('POST', '/api/auth/login', { username: 'alice_1', password: 'nope-nope' })).status, 401);
  assert.strictEqual((await c2.req('POST', '/api/auth/login', { username: 'nobody', password: 'nope-nope' })).status, 401);
  const ok = await c2.req('POST', '/api/auth/login', { username: 'ALICE_1', password: 'correct horse' });
  assert.strictEqual(ok.status, 200);
  assert.strictEqual(ok.json.role, 'registered');
});

test('login is not blocked by simulated concurrent duplicate signups (race re-check)', async () => {
  const body = { username: 'racer', password: 'racepassword' };
  const rs = await Promise.all([1, 2, 3].map((i) => client(srv.base, '10.1.0.' + i).req('POST', '/api/auth/register', body)));
  assert.strictEqual(rs.filter((r) => r.status === 201).length, 1, JSON.stringify(rs.map((r) => r.status)));
});

test('cookie: NOT Secure on plain http (LAN login works), Secure when proxied as https', async () => {
  const plain = await client(srv.base, '10.0.1.1').req('POST', '/api/auth/guest', {});
  assert.ok(plain.setCookie.includes('HttpOnly'));
  assert.ok(!/;\s*Secure/i.test(plain.setCookie), 'Secure cookie over http would silently break LAN logins: ' + plain.setCookie);

  const viaProxy = await client(srv.base, '10.0.1.2').req('POST', '/api/auth/guest', {}, { 'x-forwarded-proto': 'https' });
  assert.ok(/;\s*Secure/i.test(viaProxy.setCookie), viaProxy.setCookie);
});

test('"stay signed in" off => session cookie; on (default) => persistent', async () => {
  const keep = await client(srv.base, '10.0.2.1').req('POST', '/api/auth/guest', {});
  assert.ok(/Max-Age|Expires/i.test(keep.setCookie));
  const session = await client(srv.base, '10.0.2.2').req('POST', '/api/auth/guest', { remember: false });
  assert.ok(!/Max-Age|Expires/i.test(session.setCookie), session.setCookie);
});

test('guest: unique handle, /me works, logout clears cookie', async () => {
  const c = client(srv.base, '10.0.3.1');
  const g = await c.req('POST', '/api/auth/guest', {});
  assert.match(g.json.username, /^Guest\d{4}$/);
  assert.strictEqual((await c.req('GET', '/api/auth/me')).json.role, 'guest');
  const out = await c.req('POST', '/api/auth/logout', {});
  assert.strictEqual(out.json.ok, true);
});

test('rate limits are per real visitor IP, not one shared bucket for the whole site', async () => {
  // 20 failed logins from IP A must not affect IP B
  const a = client(srv.base, '172.16.5.1');
  let sawLimit = false;
  for (let i = 0; i < 20; i++) {
    const r = await a.req('POST', '/api/auth/login', { username: 'nobodyhere', password: 'wrongwrong' }, { 'x-zent-pow': 'skip' });
    if (r.status === 429) { sawLimit = true; break; }
    if (r.status === 428) {
      const ch = r.json.challenge;
      const proof = `${ch.token}|${solve(ch.n, ch.difficulty, 0, 1)}`;
      const r2 = await a.req('POST', '/api/auth/login', { username: 'nobodyhere', password: 'wrongwrong' }, { 'x-zent-pow': proof });
      if (r2.status === 429) { sawLimit = true; break; }
    }
  }
  assert.ok(sawLimit, 'IP A should hit the failed-login limit');
  const b = client(srv.base, '172.16.5.2');
  const r = await b.req('POST', '/api/auth/login', { username: 'nobodyhere', password: 'wrongwrong' });
  assert.strictEqual(r.status, 401, 'IP B must be unaffected, got ' + r.status);
});

test('shield: calm visitors never see a challenge; a flood does; solving works; replay fails', async () => {
  const calm = client(srv.base, '192.0.2.10');
  for (let i = 0; i < 3; i++) assert.strictEqual((await calm.req('POST', '/api/auth/guest', {})).status, 200);

  const bot = client(srv.base, '192.0.2.99');
  let challenge = null;
  for (let i = 0; i < 12; i++) {
    const r = await bot.req('POST', '/api/auth/guest', {});
    if (r.status === 428) { challenge = r.json.challenge; break; }
    assert.strictEqual(r.status, 200);
  }
  assert.ok(challenge, 'a burst of requests must trigger the human check');
  assert.ok(challenge.difficulty >= 15 && challenge.difficulty <= 20);

  const proof = `${challenge.token}|${solve(challenge.n, challenge.difficulty, 0, 1)}`;
  const ok = await bot.req('POST', '/api/auth/guest', {}, { 'x-zent-pow': proof });
  assert.strictEqual(ok.status, 200, 'solved proof should be accepted (no retry loop)');
  const replay = await bot.req('POST', '/api/auth/guest', {}, { 'x-zent-pow': proof });
  assert.strictEqual(replay.status, 428, 'a proof must be single-use');

  // proof is bound to the network it was issued for
  const other = client(srv.base, '192.0.2.77');
  const st = await bot.req('POST', '/api/auth/guest', {});
  const ch2 = st.json.challenge;
  const p2 = `${ch2.token}|${solve(ch2.n, ch2.difficulty, 0, 1)}`;
  for (let i = 0; i < 8; i++) await other.req('POST', '/api/auth/guest', {});
  const stolen = await other.req('POST', '/api/auth/guest', {}, { 'x-zent-pow': p2 });
  assert.notStrictEqual(stolen.status, 200, 'a proof issued to another network must not work');
});

test('friends API needs auth; bad input handled', async () => {
  assert.strictEqual((await client(srv.base, '10.9.0.1').req('GET', '/api/friends/me')).status, 401);
  const c = client(srv.base, '10.9.0.2');
  await c.req('POST', '/api/auth/guest', {});
  assert.strictEqual((await c.req('POST', '/api/friends/add', {})).status, 400);
  assert.strictEqual((await c.req('POST', '/api/friends/add', { code: 'ZZZZ-ZZZZ' })).status, 404);
  const me = await c.req('GET', '/api/friends/me');
  assert.strictEqual((await c.req('POST', '/api/friends/add', { code: me.json.friendCode })).status, 400);
  assert.ok(me.json.expiresAt > Date.now(), 'guest codes expire');
});
