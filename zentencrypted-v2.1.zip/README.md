# ZENT// — ZentEncrypted

Self-hosted chat you can run on a Raspberry Pi. Browser only, nothing to install for users.

- **Public room** — open to everyone, nothing stored.
- **Join-code rooms** — end-to-end encrypted. You pick how long they live; they delete themselves.
- **Friends** — add by friend code, then chat privately with no passwords.
- **Link** — one-off peer-to-peer chat between two browsers.
- **Guests welcome** — no signup needed.

Node.js + Express + Socket.io on the back, plain HTML/CSS/JS on the front. No build step, no CDNs, no third-party requests. Fonts, icons and the PeerJS library are all served from your own server.

---

## What the server can and can't see

Be clear-eyed about this; it's the whole point.

| Where | Encrypted? | What your server sees |
|---|---|---|
| **#public** | **No.** It's public. | The text, in memory, as it passes through. Never written to disk or logged. |
| **Join-code rooms** | Yes, end to end | Scrambled bytes, who's in the room, room name, when it expires. Never the code or the key. |
| **Friend chats** | Yes, end to end | Scrambled bytes and the two public keys used to agree on a key. Never a private key or the text. |
| **Link (P2P)** | Yes, twice over | Only the brief connection handshake. The conversation never touches the server. |

**No history exists anywhere.** Messages live on screen only. Close the tab and they're gone. The only things on disk are registered accounts (`data/db.json`: username + bcrypt password hash + friend list).

### How the keys work

- **Join-code rooms:** the code `LLLL-SSSS-SSSS-SSSS` has a public part (`LLLL`, finds the room) and a 60-bit secret. Your browser stretches the secret with PBKDF2 (150,000 rounds) into two independent halves: one is sent to the server to prove you know the code (the server stores only a hash of it), the other becomes the AES-256-GCM key and **never leaves your browser**.
- **Friend chats:** each browser makes a throw-away ECDH keypair, swaps public keys through the server, and both derive the same AES key. A **safety code** (hash of both public keys) is shown in the bar above the chat. If the two friends see the same code, nobody sat in the middle. If a hostile server swapped keys, the codes would differ. This is tested.
- Every message is bound to its room, so a ciphertext can't be replayed into another room.

### Honest limitations

- **No forward secrecy.** For join-code rooms, anyone who later learns the code can read anything they captured earlier. Friend-chat keys are per-session, which helps, but this isn't Signal. For high-stakes secrets, use a vetted protocol.
- **Friend chats need both people online** at the same time (nothing is stored, so nothing can wait for you).
- **A friend's safety code changes each session** (keys are throw-away), so compare it when it matters.
- **Guest friendships live in server memory.** A server restart or the 24-hour expiry wipes them.
- **Translation only works in recent Chrome/Edge.** It uses the browser's built-in on-device translator. There's deliberately no cloud fallback: that would hand your messages to a third party.
- **Link (P2P)** uses Google's public STUN server to get through home routers (PeerJS's default). Strict networks (symmetric NAT) may fail to connect; there's no server relay by design. A self-hosted TURN server (coturn) is the fix if you need it.
- **No moderation tools** for the public room. Don't expose it more widely than you're willing to watch.

---

## Setup

Node 18+ required.

```bash
npm install --omit=dev
cp .env.example .env
nano .env        # set JWT_SECRET
npm start
```

Make a secret:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Open `http://localhost:3000`.

### Keep it running (pm2)

```bash
sudo npm install -g pm2
pm2 start server.js --name zentencrypted
pm2 save
pm2 startup        # then run the line it prints
```

### Updating an existing install (Raspberry Pi)

Your accounts live in `data/db.json` and your secret lives in `.env`. **Copy both** or people lose their accounts:

```bash
cd ~
mv ZentEncrypted ZentEncrypted-old
# copy the new folder in as ~/ZentEncrypted, then:
cd ~/ZentEncrypted
cp ../ZentEncrypted-old/.env .env
cp -r ../ZentEncrypted-old/data ./data
npm install --omit=dev
pm2 restart zentencrypted
```

Check it: `curl http://localhost:3000/health` should print `{"ok":true}`.

### Behind Cloudflare Tunnel (what you're running)

Nothing special is needed. The server reads the real visitor IP from `CF-Connecting-IP` **only** when the request comes from this same machine (`cloudflared`), so rate limits apply per visitor instead of to the whole site at once. Login cookies are marked `Secure` automatically when the request arrived over HTTPS, and work over plain `http://` on your LAN too.

---

## Configuration (`.env`)

| Variable | Default | What it does |
|---|---|---|
| `JWT_SECRET` | *(required)* | Signs login sessions. 32+ random characters. |
| `PORT` | `3000` | Port to listen on. |
| `ROOM_MIN_TTL_MS` / `ROOM_MAX_TTL_MS` | 5 min / 7 days | Allowed room lifetimes. |
| `MAX_ROOMS_PER_USER` / `MAX_ROOMS_TOTAL` | 5 / 500 | Caps on active join-code rooms. |
| `WS_MAX_MESSAGES_PER_SECOND` | 5 | Per-connection message limit. |
| `WS_IDLE_TIMEOUT_MS` | 15 min | Idle connections are dropped (the page pings while you're active). |
| `SHIELD_ENABLED` | 1 | The human check (below). |
| `SHIELD_ALWAYS` | 0 | Set to `1` to make **everyone** do it while you're under attack. |
| `SHIELD_AUTH_SOFT` | 10 | Sign-in attempts per minute from one network before it kicks in. |
| `MAX_CONN_PER_IP` | 250 | Concurrent connections per network (high on purpose: schools share one IP). |

### The human check (anti-bot)

No third-party captcha. When a network sends lots of sign-in/register/guest requests, fails logins repeatedly, or the whole site is being flooded, the server asks the browser to do a small proof-of-work puzzle (about a second of CPU, more if it's misbehaving). Normal visitors never see it. Each puzzle is single-use and tied to the requester's network. For real volumetric attacks, keep Cloudflare in front: this protects the app, Cloudflare protects the pipe.

---

## Customising

- **Icon:** replace the files in `public/icons/` (`icon-192.png`, `icon-512.png`, `apple-touch-icon.png`, `favicon-32.png`) plus `public/favicon.svg` and `public/favicon.ico`. The ones included are placeholders.
- **Themes:** Settings → Look. Seven built in, plus a custom builder. Themes can be shared as a short `ZT1.…` code.
- **Fonts:** Bricolage Grotesque and JetBrains Mono (SIL Open Font License, licences in `public/fonts/`).

## Tests

```bash
npm install          # (includes dev tools: jsdom, socket.io-client)
npm test
```

54 tests: crypto (including man-in-the-middle detection), the human check, auth/cookies/rate limits, realtime rooms/expiry/DMs/abuse cases, and the real page driven in a simulated browser. It does **not** cover how the design looks or the peer-to-peer Link tab (both need a real browser).

## Layout

```
server.js            entry point
config/database.js   user store (lowdb)
src/                 auth, rooms, realtime, friends, shield (human check), identity
public/              the whole front end (no build step)
test/                the test suite
```

## License

MIT. Fonts under the SIL Open Font License. PeerJS under its own MIT licence.
