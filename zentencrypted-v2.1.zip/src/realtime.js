/**
 * src/realtime.js
 * All WebSocket behaviour.
 *
 *  - public room:   plaintext relay (it's public). Never stored or logged.
 *  - join-code rooms and DMs: the server relays opaque ciphertext only.
 *  - DMs: the server also relays the two public keys the friends use to
 *    agree on a key, but it never sees any private key or plaintext.
 *
 * Nothing in here writes message content anywhere. There is no history.
 */
const jwt = require('jsonwebtoken');
const cookie = require('cookie');
const crypto = require('crypto');
const { JWT_SECRET } = require('./auth');
const rooms = require('./rooms');
const id = require('./identity');
const shield = require('./shield');
const bus = require('./bus');
const { fromRequest, keyFor } = require('./clientIp');

const num = (v, d) => (Number.isFinite(Number(v)) && v !== undefined && v !== '' ? Number(v) : d);
const MAX_MSGS_PER_SEC = num(process.env.WS_MAX_MESSAGES_PER_SECOND, 5);
const MAX_PAYLOAD_BYTES = num(process.env.WS_MAX_PAYLOAD_BYTES, 12 * 1024);
const IDLE_TIMEOUT_MS = num(process.env.WS_IDLE_TIMEOUT_MS, 15 * 60 * 1000);
const PUBLIC_MAX_CHARS = 1000;
const CIPHER_MAX_CHARS = 7000;

const uidFor = (userId) =>
  crypto.createHmac('sha256', JWT_SECRET).update('uid:' + userId).digest('hex').slice(0, 10);

const noop = () => {};
const fn = (f) => (typeof f === 'function' ? f : noop);

function byteSize(obj) {
  try {
    return Buffer.byteLength(JSON.stringify(obj));
  } catch {
    return Infinity;
  }
}

function cleanText(raw) {
  return String(raw)
    .replace(/[\u0000-\u0008\u000B-\u001F\u007F\u200B-\u200F\u202A-\u202E\u2066-\u2069]/g, '')
    .trim();
}

function authenticateSocket(socket, next) {
  try {
    const parsed = cookie.parse(socket.handshake.headers.cookie || '');
    if (!parsed.token) return next(new Error('Unauthorized'));
    const p = jwt.verify(parsed.token, JWT_SECRET);
    // Identity must still exist (guest records vanish on restart / after 24h).
    if (!id.getIdentity(p.sub)) return next(new Error('Unauthorized'));
    socket.user = { id: p.sub, username: p.username, role: p.role, uid: uidFor(p.sub) };
    next();
  } catch {
    next(new Error('Unauthorized'));
  }
}

function attach(io) {
  io.use(authenticateSocket);

  // Cap connections per network. Rejecting during the handshake means the
  // browser gets an explicit connect_error instead of hanging.
  io.use((socket, next) => {
    const key = keyFor(fromRequest(socket.request));
    if (!shield.connOpen(key)) return next(new Error('Too many connections'));
    socket.once('disconnect', () => shield.connClose(key));
    next();
  });

  const userRoom = (userId) => `u:${userId}`;
  const isOnline = (userId) => (io.sockets.adapter.rooms.get(userRoom(userId))?.size || 0) > 0;

  function announceCount(key) {
    const r = rooms.get(key);
    if (r) io.to(key).emit('room:count', { room: key, count: r.members.size });
  }

  function enter(socket, key) {
    if (socket.rooms.has(key)) return rooms.get(key);
    socket.join(key);
    const r = rooms.join(key, socket.id);
    io.to(key).emit('presence:join', { room: key, username: socket.user.username, uid: socket.user.uid });
    announceCount(key);
    return r;
  }

  function exit(socket, key) {
    const wasIn = socket.rooms.has(key);
    socket.leave(key);
    const r = rooms.leave(key, socket.id);
    if (wasIn) io.to(key).emit('presence:leave', { room: key, username: socket.user.username, uid: socket.user.uid });
    if (r) announceCount(key);
  }

  io.on('connection', (socket) => {
    const { id: userId, username, role, uid } = socket.user;

    let stamps = [];
    let dmKeyStamps = [];
    let createStamps = [];
    let joinFails = [];
    let typingAt = 0;
    let idleTimer = null;

    const bump = () => {
      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        socket.emit('session:idle', { message: 'Disconnected after a period of inactivity.' });
        socket.disconnect(true);
      }, IDLE_TIMEOUT_MS);
    };
    bump();

    const limited = () => {
      const now = Date.now();
      stamps = stamps.filter((t) => now - t < 1000);
      stamps.push(now);
      return stamps.length > MAX_MSGS_PER_SEC;
    };

    // First tab for this person => tell their friends they're online.
    socket.join(userRoom(userId));
    const sockets = io.sockets.adapter.rooms.get(userRoom(userId));
    if (sockets && sockets.size === 1) {
      for (const f of id.getIdentity(userId)?.friends || []) io.to(userRoom(f)).emit('friend:presence', { id: userId, online: true });
    }

    enter(socket, rooms.PUBLIC);
    socket.emit('session:ready', { id: userId, uid, username, role, room: rooms.PUBLIC });

    /* ---------- joining / creating ---------- */
    socket.on('room:create', (p, ack) => {
      ack = fn(ack);
      bump();
      const now = Date.now();
      createStamps = createStamps.filter((t) => now - t < 10 * 60 * 1000);
      if (createStamps.length >= 6) return ack({ ok: false, error: "You're creating rooms too fast. Wait a few minutes." });
      if (!p || typeof p !== 'object') return ack({ ok: false, error: 'Bad request.' });

      const res = rooms.createCodeRoom({
        locator: p.locator, name: p.name, auth: p.auth, ownerId: userId,
        ttlMs: p.ttlMs, burnWhenEmpty: p.burnWhenEmpty,
      });
      if (!res.ok) return ack(res);
      createStamps.push(now); // only rooms that actually got created count against the allowance
      enter(socket, res.room.key);
      ack({ ok: true, room: rooms.info(res.room) });
    });

    socket.on('room:join', (p, ack) => {
      ack = fn(ack);
      bump();
      if (!p || typeof p !== 'object') return ack({ ok: false, error: 'Bad request.' });

      // Public
      if (p.room === rooms.PUBLIC) {
        enter(socket, rooms.PUBLIC);
        return ack({ ok: true, room: rooms.info(rooms.get(rooms.PUBLIC)) });
      }

      // Direct message between friends
      if (typeof p.room === 'string' && p.room.startsWith('dm:')) {
        const pair = id.parseDmRoom(p.room);
        if (!pair || !pair.includes(userId)) return ack({ ok: false, error: 'Not your conversation.' });
        const other = pair[0] === userId ? pair[1] : pair[0];
        if (!id.areFriends(userId, other) || !id.areFriends(other, userId)) {
          return ack({ ok: false, error: "You're not friends with this person (anymore)." });
        }
        // One tab per person per DM: the key exchange is per-browser.
        const existing = rooms.ensureDm(p.room);
        for (const sid of Array.from(existing.members)) {
          const s = io.sockets.sockets.get(sid);
          if (s && sid !== socket.id && s.user.id === userId) {
            s.emit('room:kicked', { room: p.room, reason: 'You opened this conversation in another tab.' });
            exit(s, p.room);
          }
        }
        rooms.ensureDm(p.room);
        const wasIn = socket.rooms.has(p.room);
        enter(socket, p.room);
        // Tell the friend someone is waiting for them (only if they aren't already in the room).
        if (!wasIn && rooms.get(p.room).members.size === 1) {
          io.to(userRoom(other)).emit('dm:ring', { room: p.room, from: userId, username });
        }
        return ack({ ok: true, room: rooms.info(rooms.get(p.room)), peer: other, peerOnline: isOnline(other) });
      }

      // Join-code room
      const now = Date.now();
      joinFails = joinFails.filter((t) => now - t < 5 * 60 * 1000);
      if (joinFails.length >= 8) return ack({ ok: false, error: 'Too many wrong codes. Wait a few minutes.' });
      const v = rooms.verifyJoin(p.locator, p.auth);
      if (!v.ok) {
        joinFails.push(now);
        return ack(v);
      }
      enter(socket, v.room.key);
      ack({ ok: true, room: rooms.info(v.room) });
    });

    socket.on('room:leave', (p, ack) => {
      ack = fn(ack);
      bump();
      const key = p && p.room;
      if (typeof key !== 'string' || key === rooms.PUBLIC) return ack({ ok: false });
      exit(socket, key);
      ack({ ok: true });
    });

    /* ---------- messages ---------- */
    socket.on('message:send', (p, ack) => {
      ack = fn(ack);
      bump();
      if (limited()) return ack({ ok: false, error: "You're sending messages too fast." });
      if (!p || typeof p !== 'object' || byteSize(p) > MAX_PAYLOAD_BYTES) {
        return ack({ ok: false, error: 'That message is too large.' });
      }
      const key = p.room;
      if (typeof key !== 'string' || !socket.rooms.has(key)) return ack({ ok: false, error: 'Join the room first.' });
      const room = rooms.get(key);
      if (!room) return ack({ ok: false, error: 'That room is gone.' });

      const msg = { id: crypto.randomBytes(6).toString('hex'), room: key, sender: username, uid, ts: Date.now() };
      if (room.type === 'public') {
        if (typeof p.text !== 'string') return ack({ ok: false, error: 'Malformed message.' });
        const text = cleanText(p.text);
        if (!text) return ack({ ok: false, error: 'Empty message.' });
        if (text.length > PUBLIC_MAX_CHARS) return ack({ ok: false, error: `Max ${PUBLIC_MAX_CHARS} characters in public.` });
        msg.text = text;
      } else {
        const { ciphertext, iv } = p;
        if (typeof ciphertext !== 'string' || typeof iv !== 'string' || !ciphertext || !iv ||
            ciphertext.length > CIPHER_MAX_CHARS || iv.length > 32) {
          return ack({ ok: false, error: 'Malformed message.' });
        }
        msg.ciphertext = ciphertext;
        msg.iv = iv;
      }
      io.to(key).emit('message:receive', msg);
      ack({ ok: true, id: msg.id });
    });

    socket.on('typing', (p) => {
      bump();
      const now = Date.now();
      if (now - typingAt < 700) return;
      typingAt = now;
      const key = p && p.room;
      if (typeof key === 'string' && socket.rooms.has(key)) socket.to(key).emit('typing', { room: key, username, uid });
    });

    /* ---------- DM key exchange (public keys only) ---------- */
    socket.on('dm:key', (p) => {
      bump();
      const now = Date.now();
      dmKeyStamps = dmKeyStamps.filter((t) => now - t < 60000);
      if (dmKeyStamps.length >= 30) return;
      dmKeyStamps.push(now);
      if (!p || typeof p.room !== 'string' || !p.room.startsWith('dm:') || !socket.rooms.has(p.room)) return;
      if (typeof p.pub !== 'string' || p.pub.length > 200 || !/^[A-Za-z0-9+/=]+$/.test(p.pub)) return;
      if (p.kind !== 'hello' && p.kind !== 'ack') return;
      socket.to(p.room).emit('dm:key', { room: p.room, pub: p.pub, kind: p.kind, from: uid });
    });

    /* ---------- friends ---------- */
    socket.on('friends:online', (_p, ack) => {
      ack = fn(ack);
      const friends = id.getIdentity(userId)?.friends || [];
      ack({ online: friends.filter(isOnline) });
    });

    socket.on('activity', bump);

    socket.on('disconnect', () => {
      if (idleTimer) clearTimeout(idleTimer);
      for (const key of rooms.leaveAll(socket.id)) {
        io.to(key).emit('presence:leave', { room: key, username, uid });
        announceCount(key);
      }
      if (!isOnline(userId)) {
        for (const f of id.getIdentity(userId)?.friends || []) io.to(userRoom(f)).emit('friend:presence', { id: userId, online: false });
      }
    });
  });

  /* ---------- server-side events ---------- */
  bus.on('friends:changed', (ids) => ids.forEach((i) => io.to(userRoom(i)).emit('friends:changed')));
  bus.on('friends:removed', ({ room }) => {
    io.to(room).emit('room:kicked', { room, reason: 'This friendship was removed.' });
    io.in(room).socketsLeave(room);
    rooms.destroy(room);
  });

  // Burn rooms whose time is up (or that emptied out, if set to burn when empty).
  const sweeper = setInterval(() => {
    for (const { room, reason } of rooms.expireDue()) {
      io.to(room.key).emit('room:expired', { room: room.key, name: room.name, reason });
      io.in(room.key).socketsLeave(room.key);
    }
  }, num(process.env.ROOM_SWEEP_MS, 5000));
  sweeper.unref();
}

module.exports = { attach, MAX_PAYLOAD_BYTES };
