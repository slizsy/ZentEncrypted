/**
 * src/shield.js
 * Adaptive anti-abuse for sign-in / register / guest endpoints.
 *
 * Normal visitors never see anything. When a client trips a threshold the
 * server answers 428 with a proof-of-work challenge (hashcash style): the
 * browser has to find a counter so SHA-256("<nonce>:<counter>") starts with
 * N zero bits. That costs a real person about a second and costs a botnet
 * real CPU per request. No third-party captcha, nothing leaves your server.
 *
 * Triggers (all env-tunable, see .env.example):
 *   - too many auth attempts from one network in 60s
 *   - repeated failed logins from one network
 *   - the whole site is being hammered (global attack mode)
 *   - request has no User-Agent at all
 *   - SHIELD_ALWAYS=1 forces it for everyone (handy if you're under attack)
 */
const crypto = require('crypto');
const { fromRequest, keyFor } = require('./clientIp');

const num = (v, d) => (Number.isFinite(Number(v)) && v !== undefined && v !== '' ? Number(v) : d);

const CFG = {
  enabled: process.env.SHIELD_ENABLED !== '0',
  always: process.env.SHIELD_ALWAYS === '1',
  soft: num(process.env.SHIELD_AUTH_SOFT, 10), // passes / 60s before challenges start
  globalPer10s: num(process.env.SHIELD_GLOBAL_PER_10S, 80),
  ttlMs: 2 * 60 * 1000,
  maxConnPerIp: num(process.env.MAX_CONN_PER_IP, 250),
  maxNewConnPerMin: num(process.env.MAX_NEW_CONN_PER_MIN, 500),
};

const SECRET = crypto
  .createHmac('sha256', process.env.JWT_SECRET || 'dev-only-secret')
  .update('zent-shield-v1')
  .digest();

const perIp = new Map(); // key -> { hits: number[], fails: number[] }
let globalHits = [];
const usedNonces = new Map(); // nonce -> expiry
const conns = new Map(); // key -> { open, recent: number[] }

function rec(key) {
  let r = perIp.get(key);
  if (!r) perIp.set(key, (r = { hits: [], fails: [] }));
  return r;
}

setInterval(() => {
  const now = Date.now();
  for (const [k, r] of perIp) {
    r.hits = r.hits.filter((t) => now - t < 600000);
    r.fails = r.fails.filter((t) => now - t < 600000);
    if (!r.hits.length && !r.fails.length) perIp.delete(k);
  }
  globalHits = globalHits.filter((t) => now - t < 10000);
  for (const [n, exp] of usedNonces) if (exp < now) usedNonces.delete(n);
  for (const [k, c] of conns) {
    c.recent = c.recent.filter((t) => now - t < 60000);
    if (!c.open && !c.recent.length) conns.delete(k);
  }
}, 30000).unref();

function underAttack(now = Date.now()) {
  return globalHits.filter((t) => now - t < 10000).length > CFG.globalPer10s;
}

function difficultyFor(key, req) {
  if (!CFG.enabled) return 0;
  const now = Date.now();
  let d = 0;
  if (CFG.always) d = 14;
  const r = perIp.get(key);
  if (r) {
    const hits = r.hits.filter((t) => now - t < 60000).length;
    const fails = r.fails.filter((t) => now - t < 600000).length;
    if (hits > CFG.soft) d = Math.max(d, Math.min(20, 15 + (hits - CFG.soft)));
    if (fails >= 3) d = Math.max(d, Math.min(20, 15 + (fails - 2)));
  }
  if (underAttack(now)) d = Math.max(d, 17);
  if (req && !req.get('user-agent')) d = Math.max(d, 16);
  return d;
}

function note(key) {
  const now = Date.now();
  rec(key).hits.push(now);
  globalHits.push(now);
}

function noteFail(req) {
  rec(keyFor(fromRequest(req))).fails.push(Date.now());
}

function noteSuccess(req) {
  const r = perIp.get(keyFor(fromRequest(req)));
  if (r) r.fails = [];
}

const ipTag = (key) => crypto.createHmac('sha256', SECRET).update('ip:' + key).digest('hex').slice(0, 16);

function sign(body) {
  return crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
}

function issue(difficulty, key) {
  const payload = {
    n: crypto.randomBytes(12).toString('hex'),
    d: difficulty,
    e: Date.now() + CFG.ttlMs,
    i: ipTag(key),
  };
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return { token: `${body}.${sign(body)}`, n: payload.n, difficulty };
}

function leadingZeroBits(buf) {
  let bits = 0;
  for (const byte of buf) {
    if (byte === 0) {
      bits += 8;
      continue;
    }
    bits += Math.clz32(byte) - 24;
    break;
  }
  return bits;
}

/** proof = "<token>|<counter>" */
function verify(proof, needed, key) {
  try {
    const [token, counter] = String(proof).split('|');
    if (!token || !/^\d{1,12}$/.test(counter || '')) return false;
    const [body, sig] = token.split('.');
    if (!body || !sig) return false;
    const expect = sign(body);
    const a = Buffer.from(sig);
    const b = Buffer.from(expect);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (p.e < Date.now() || p.i !== ipTag(key) || p.d < needed) return false;
    if (usedNonces.has(p.n)) return false;
    const hash = crypto.createHash('sha256').update(`${p.n}:${counter}`).digest();
    if (leadingZeroBits(hash) < p.d) return false;
    usedNonces.set(p.n, p.e + 1000);
    return true;
  } catch {
    return false;
  }
}

/**
 * Express middleware. Order matters: the difficulty is computed from
 * *previous* passes, and only passing requests are counted — otherwise the
 * retry carrying a solved proof would raise its own bar and loop forever.
 */
function guard() {
  return (req, res, next) => {
    const key = keyFor(fromRequest(req));
    const need = difficultyFor(key, req);
    if (!need) {
      note(key);
      return next();
    }
    const proof = req.get('x-zent-pow');
    if (proof && verify(proof, need, key)) {
      note(key);
      return next();
    }
    return res.status(428).json({
      error: 'Quick human check needed before continuing.',
      challenge: issue(need, key),
    });
  };
}

/* ---- WebSocket connection limiter ---- */
function connOpen(key) {
  const now = Date.now();
  let c = conns.get(key);
  if (!c) conns.set(key, (c = { open: 0, recent: [] }));
  c.recent = c.recent.filter((t) => now - t < 60000);
  if (c.open >= CFG.maxConnPerIp || c.recent.length >= CFG.maxNewConnPerMin) return false;
  c.open += 1;
  c.recent.push(now);
  return true;
}

function connClose(key) {
  const c = conns.get(key);
  if (c) c.open = Math.max(0, c.open - 1);
}

function status() {
  return { underAttack: underAttack(), tracked: perIp.size, config: { ...CFG } };
}

module.exports = { guard, noteFail, noteSuccess, connOpen, connClose, status, leadingZeroBits, _verify: verify, _issue: issue, _difficultyFor: difficultyFor };
