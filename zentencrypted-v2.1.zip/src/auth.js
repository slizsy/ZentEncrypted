/**
 * src/auth.js
 * Registration, login, guest sessions. Passwords hashed with bcrypt;
 * sessions are stateless JWTs in an httpOnly cookie.
 */
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const guestRegistry = require('./guestRegistry');
const shield = require('./shield');
const { fromRequest, keyFor } = require('./clientIp');

const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const SALT_ROUNDS = 12;
const REMEMBER_MS = 7 * 24 * 60 * 60 * 1000;

if (!JWT_SECRET || JWT_SECRET.length < 16) {
  throw new Error('JWT_SECRET is missing or too short. Copy .env.example to .env and set a long random secret.');
}

// A real hash to compare against when the username doesn't exist, so a
// wrong username takes as long as a wrong password (no user enumeration).
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', SALT_ROUNDS);

const limiterBase = {
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => keyFor(fromRequest(req)),
  validate: false,
};
const loginLimiter = rateLimit({
  ...limiterBase,
  windowMs: 15 * 60 * 1000,
  max: Number(process.env.LOGIN_RATE_LIMIT_MAX || 15),
  skipSuccessfulRequests: true, // only failures count
  message: { error: 'Too many failed attempts. Please wait a few minutes.' },
});
const registerLimiter = rateLimit({
  ...limiterBase,
  windowMs: 60 * 60 * 1000,
  max: 12,
  message: { error: 'Too many accounts created from this network. Try again later.' },
});
const guestLimiter = rateLimit({
  ...limiterBase,
  windowMs: 15 * 60 * 1000,
  max: 80, // a whole school can sit behind one IP
  message: { error: 'Too many guest sessions from this network. Try again shortly.' },
});

const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const RESERVED = /^(admin|administrator|system|server|zent|zentencrypted|mod|moderator|support|staff|you|them|root|null|undefined|guest\d*)$/i;

function signToken(user) {
  return jwt.sign({ sub: user.id, username: user.username, role: 'registered' }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });
}

/** `secure` follows the real protocol, so plain-http LAN access still works. */
function setAuthCookie(req, res, token, remember = true, maxAgeMs = REMEMBER_MS) {
  const opts = { httpOnly: true, sameSite: 'lax', secure: !!req.secure };
  if (remember) opts.maxAge = maxAgeMs; // omitted => session cookie (dies with the browser)
  res.cookie('token', token, opts);
}

router.post('/register', shield.guard(), registerLimiter, async (req, res) => {
  try {
    const { username, password, remember } = req.body || {};
    if (typeof username !== 'string' || typeof password !== 'string' || !username || !password) {
      return res.status(400).json({ error: 'Username and password are required.' });
    }
    if (!USERNAME_RE.test(username)) {
      return res.status(400).json({ error: 'Username must be 3-20 characters: letters, numbers, underscore.' });
    }
    if (RESERVED.test(username)) {
      return res.status(400).json({ error: 'That username is reserved.' });
    }
    if (password.length < 8 || password.length > 200) {
      return res.status(400).json({ error: 'Password must be 8-200 characters.' });
    }
    if (db.get('users').find({ usernameLower: username.toLowerCase() }).value()) {
      return res.status(409).json({ error: 'That username is taken.' });
    }

    const user = {
      id: uuidv4(),
      username,
      usernameLower: username.toLowerCase(),
      passwordHash: await bcrypt.hash(password, SALT_ROUNDS),
      friendCode: db.generateFriendCode(guestRegistry.codeTaken),
      friends: [],
      createdAt: new Date().toISOString(),
    };
    // Re-check after the (slow) hash so two simultaneous signups can't both win.
    if (db.get('users').find({ usernameLower: user.usernameLower }).value()) {
      return res.status(409).json({ error: 'That username is taken.' });
    }
    db.get('users').push(user).write();

    setAuthCookie(req, res, signToken(user), remember !== false);
    return res.status(201).json({ id: user.id, username: user.username, role: 'registered' });
  } catch (err) {
    console.error('Register error:', err);
    return res.status(500).json({ error: 'Something went wrong on our end.' });
  }
});

router.post('/login', shield.guard(), loginLimiter, async (req, res) => {
  try {
    const { username, password, remember } = req.body || {};
    if (typeof username !== 'string' || typeof password !== 'string' || !username || !password) {
      return res.status(400).json({ error: 'Username and password are required.' });
    }
    const user = db.get('users').find({ usernameLower: username.toLowerCase() }).value();
    const valid = await bcrypt.compare(password.slice(0, 200), user ? user.passwordHash : DUMMY_HASH);
    if (!user || !valid) {
      shield.noteFail(req);
      return res.status(401).json({ error: 'Incorrect username or password.' });
    }
    shield.noteSuccess(req);

    // Backfill for accounts created before friend codes existed.
    if (!user.friendCode) {
      db.get('users')
        .find({ id: user.id })
        .assign({ friendCode: db.generateFriendCode(guestRegistry.codeTaken), friends: user.friends || [] })
        .write();
    }
    setAuthCookie(req, res, signToken(user), remember !== false);
    return res.json({ id: user.id, username: user.username, role: 'registered' });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Something went wrong on our end.' });
  }
});

router.post('/guest', shield.guard(), guestLimiter, (req, res) => {
  const guestId = uuidv4();
  let handle;
  do {
    handle = `Guest${crypto.randomInt(1000, 10000)}`;
  } while (guestRegistry.nameTaken(handle));

  guestRegistry.register(guestId, handle, db.codeTaken);
  const token = jwt.sign({ sub: guestId, username: handle, role: 'guest' }, JWT_SECRET, { expiresIn: '24h' });
  setAuthCookie(req, res, token, req.body && req.body.remember !== false, guestRegistry.TTL_MS);
  return res.json({ id: guestId, username: handle, role: 'guest' });
});

router.post('/logout', (req, res) => {
  res.clearCookie('token', { httpOnly: true, sameSite: 'lax', secure: !!req.secure });
  return res.json({ ok: true });
});

function readSession(req) {
  const token = req.cookies && req.cookies.token;
  if (!token) return null;
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}

router.get('/me', (req, res) => {
  const p = readSession(req);
  if (!p) return res.status(401).json({ error: 'Not signed in.' });
  // A guest whose in-memory record is gone (server restart / 24h expiry)
  // is no longer a valid session, even if the JWT itself hasn't expired.
  if (p.role === 'guest' && !guestRegistry.get(p.sub)) {
    return res.status(401).json({ error: 'Guest session ended.' });
  }
  return res.json({ id: p.sub, username: p.username, role: p.role });
});

function requireAuth(req, res, next) {
  const p = readSession(req);
  if (!p) return res.status(401).json({ error: 'Not signed in.' });
  req.user = p;
  next();
}

module.exports = router;
module.exports.JWT_SECRET = JWT_SECRET;
module.exports.requireAuth = requireAuth;
module.exports.readSession = readSession;
