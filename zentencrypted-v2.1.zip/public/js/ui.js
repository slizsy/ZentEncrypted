/**
 * ui.js
 * Rendering helpers: the message logs, toasts, modals, the mode strip.
 * Everything is built with textContent / createElement, never innerHTML
 * with user data, so a message can't inject markup.
 */
const Ui = (() => {
  const $ = (id) => document.getElementById(id);

  /** tiny hyperscript: h('div', {class:'x', on:{click:fn}}, 'text', child) */
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'on') for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else if (k === 'vars') for (const [name, val] of Object.entries(v)) el.style.setProperty(name, val);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    return el;
  }

  const motionOn = () => document.documentElement.dataset.motion !== 'off';

  /* ---------------- toasts ---------------- */
  function toast(message, kind = 'info', ms = 3800) {
    const host = $('toasts');
    const t = h('div', { class: 'toast' + (kind === 'error' ? ' is-error' : ''), role: 'status', text: message });
    host.append(t);
    while (host.children.length > 4) host.firstChild.remove();
    setTimeout(() => {
      t.classList.add('is-out');
      setTimeout(() => t.remove(), motionOn() ? 260 : 0);
    }, ms);
  }

  /* ---------------- modals ---------------- */
  const openModals = [];
  function openModal(id) {
    const m = $(id);
    if (!m) return;
    m.classList.add('is-open');
    if (!openModals.includes(id)) openModals.push(id);
    const first = m.querySelector('input:not([type=checkbox]):not(.is-hidden), button:not([data-close])');
    if (first) setTimeout(() => first.focus({ preventScroll: true }), 30);
  }
  function closeModal(id) {
    const m = $(id);
    if (m) m.classList.remove('is-open');
    const i = openModals.indexOf(id);
    if (i >= 0) openModals.splice(i, 1);
  }
  const topModal = () => openModals[openModals.length - 1] || null;

  /** In-app replacement for window.confirm. Resolves true/false. */
  function confirmBox({ title = 'Are you sure?', text = '', ok = 'Do it', danger = true }) {
    return new Promise((resolve) => {
      $('cf-title').textContent = title;
      $('cf-text').textContent = text;
      const okBtn = $('cf-ok');
      okBtn.textContent = ok;
      okBtn.classList.toggle('btn-danger', danger);
      okBtn.classList.toggle('btn-solid', !danger);
      const done = (v) => {
        okBtn.removeEventListener('click', yes);
        $('cf-cancel').removeEventListener('click', no);
        $('dlg-confirm').removeEventListener('click', backdrop);
        closeModal('dlg-confirm');
        resolve(v);
      };
      const yes = () => done(true);
      const no = () => done(false);
      const backdrop = (e) => { if (e.target.id === 'dlg-confirm') done(false); };
      okBtn.addEventListener('click', yes);
      $('cf-cancel').addEventListener('click', no);
      $('dlg-confirm').addEventListener('click', backdrop);
      openModal('dlg-confirm');
      $('cf-cancel').focus();
    });
  }

  async function copy(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      const ta = h('textarea', { 'aria-hidden': 'true' });
      ta.value = text;
      ta.style.position = 'fixed'; // (individual properties are CSP-safe; cssText is not)
      ta.style.opacity = '0';
      ta.style.left = '-999px';
      document.body.append(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch { /* blocked */ }
      ta.remove();
      return ok;
    }
  }

  /* ---------------- small formatters ---------------- */
  function hueOf(str) {
    let x = 7;
    for (const ch of String(str)) x = (x * 31 + ch.charCodeAt(0)) >>> 0;
    return x % 360;
  }

  function fmtTime(ts, hour24) {
    return new Date(ts).toLocaleTimeString([], { hour: hour24 ? '2-digit' : 'numeric', minute: '2-digit', hour12: !hour24 });
  }

  function fmtRemaining(ms) {
    if (ms <= 0) return '00:00:00';
    const s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400);
    const hh = Math.floor((s % 86400) / 3600);
    const mm = Math.floor((s % 3600) / 60);
    const ss = s % 60;
    const p = (n) => String(n).padStart(2, '0');
    return d > 0 ? `${d}d ${p(hh)}h` : `${p(hh)}:${p(mm)}:${p(ss)}`;
  }

  /* ---------------- message logs (one per room) ---------------- */
  const logs = new Map(); // key -> { el, lastUid, lastTs, stick, empty }
  const MAX_ROWS = 400;

  function getLog(key) {
    let L = logs.get(key);
    if (L) return L;
    const el = h('div', { class: 'log', 'data-room': key });
    L = { el, lastUid: null, lastTs: 0, stick: true, empty: null };
    el.addEventListener('scroll', () => {
      L.stick = el.scrollHeight - el.scrollTop - el.clientHeight < 90;
      if (L.stick && el.classList.contains('is-visible')) $('jump-btn').classList.add('is-hidden');
    });
    $('stream').append(el);
    logs.set(key, L);
    return L;
  }

  function showLog(key) {
    for (const [k, L] of logs) L.el.classList.toggle('is-visible', k === key);
    const L = getLog(key);
    L.el.classList.add('is-visible');
    L.el.scrollTop = L.el.scrollHeight;
    L.stick = true;
    $('jump-btn').classList.add('is-hidden');
  }

  function dropEmpty(L) {
    if (L.empty) { L.empty.remove(); L.empty = null; }
  }

  function setEmpty(key, nodes) {
    const L = getLog(key);
    if (L.el.querySelector('.msg')) return;
    dropEmpty(L);
    L.empty = h('div', { class: 'log-empty' }, nodes);
    L.el.append(L.empty);
  }

  function pushRow(L, row, forceStick) {
    dropEmpty(L);
    L.el.append(row);
    while (L.el.children.length > MAX_ROWS) L.el.firstChild.remove();
    const visible = L.el.classList.contains('is-visible');
    if (forceStick || L.stick) L.el.scrollTop = L.el.scrollHeight;
    else if (visible) $('jump-btn').classList.remove('is-hidden');
  }

  /**
   * Adds a message. Returns { row, body } so callers can attach a translation.
   * Consecutive messages from the same person within 2 minutes are merged.
   */
  function addMessage(key, m, { hour24 = false } = {}) {
    const L = getLog(key);
    const cont = L.lastUid === m.uid && m.ts - L.lastTs < 120000 && !m.own === !L.lastOwn;
    L.lastUid = m.uid; L.lastTs = m.ts; L.lastOwn = !!m.own;
    const body = h('div', { class: 'msg-body', text: m.text });
    const row = h(
      'div',
      { class: 'msg' + (m.own ? ' is-own' : '') + (cont ? ' is-cont' : '') + (m.failed ? ' is-failed' : ''), vars: { '--h': String(hueOf(m.uid || m.sender)) } },
      h('time', { class: 'msg-time', datetime: new Date(m.ts).toISOString(), text: fmtTime(m.ts, hour24) }),
      h('span', { class: 'msg-who', text: m.own ? 'you' : m.sender }),
      body
    );
    pushRow(L, row, !!m.own);
    return { row, body };
  }

  function addSystem(key, text, warn = false) {
    const L = getLog(key);
    L.lastUid = null;
    pushRow(L, h('div', { class: 'sys' + (warn ? ' is-warn' : ''), text }), false);
  }

  function setCompact(on) {
    for (const L of logs.values()) L.el.classList.toggle('is-compact', on);
  }

  function burnLog(key) {
    const L = logs.get(key);
    if (!L) return Promise.resolve();
    L.el.classList.add('is-burning');
    return new Promise((r) => setTimeout(() => { removeLog(key); r(); }, motionOn() ? 1150 : 0));
  }

  function removeLog(key) {
    const L = logs.get(key);
    if (L) { L.el.remove(); logs.delete(key); }
  }

  function clearAllLogs() {
    for (const L of logs.values()) L.el.remove();
    logs.clear();
  }

  function scrollToEnd(key) {
    const L = logs.get(key);
    if (L) { L.el.scrollTop = L.el.scrollHeight; L.stick = true; }
    $('jump-btn').classList.add('is-hidden');
  }

  /* ---------------- header / strip ---------------- */
  function setMode(mode, stampText, text) {
    const strip = $('mode-strip');
    const stamp = $('mode-stamp');
    strip.dataset.mode = mode;
    const line = Array(3).fill(text).join('     ///     ');
    $('mode-text').textContent = line;
    $('mode-text-2').textContent = line;
    if (stamp.textContent !== stampText) {
      stamp.textContent = stampText;
      stamp.className = 'stamp stamp-' + (mode === 'open' ? 'open' : mode === 'wait' ? 'wait' : 'sealed');
      void stamp.offsetWidth; // restart the slam animation
      stamp.classList.add('is-flip');
    }
  }

  function setSignal(state) {
    $('signal').dataset.state = state;
    $('signal').setAttribute('aria-label', state === 'up' ? 'Connected' : state === 'wait' ? 'Reconnecting' : 'Offline');
  }

  function setTyping(text) {
    $('typing').classList.toggle('is-hidden', !text);
    $('typing-text').textContent = text || '';
  }

  function swapScreen(show, hide) {
    if (!motionOn()) {
      hide.classList.add('is-hidden');
      show.classList.remove('is-hidden');
      return;
    }
    hide.classList.add('screen-leave');
    setTimeout(() => {
      hide.classList.add('is-hidden');
      hide.classList.remove('screen-leave');
      show.classList.remove('is-hidden');
      show.classList.add('screen-enter');
      setTimeout(() => show.classList.remove('screen-enter'), 450);
    }, 190);
  }

  return {
    $, h, toast, openModal, closeModal, topModal, confirmBox, copy, hueOf, fmtTime, fmtRemaining,
    getLog, showLog, setEmpty, addMessage, addSystem, setCompact, burnLog, removeLog, clearAllLogs, scrollToEnd,
    setMode, setSignal, setTyping, swapScreen, motionOn,
  };
})();
