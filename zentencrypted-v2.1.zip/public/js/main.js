/**
 * main.js
 * The ZentEncrypted client. Glues Settings, Themes, Vault (crypto), Api,
 * Net (sockets), PeerSession (peer-to-peer), Translate and Ui together.
 */
(() => {
  const { $, h } = Ui;
  const PUBLIC = 'public';
  const P2P = 'p2p';
  const SITE_TITLE = 'ZENT — sealed chat';
  const ROOMS_KEY = 'zent_rooms';

  const state = {
    me: null, // { id, uid, username, role }
    current: PUBLIC,
    rooms: new Map(), // key -> room
    friends: [],
    online: new Set(),
    ringing: new Set(), // friend ids who opened a chat with us
    justAdded: new Set(), // friends I just added myself (so I don't get a second toast)
    typing: new Map(), // key -> Map(uid -> { name, timer })
    ready: false,
    sending: false,
    createdRoom: null,
  };

  const makeRoom = (o) => ({ count: 0, unread: 0, ...o });

  /** Browsers that block storage throw on access; never let that stop the app. */
  const store = {
    get(area, k) { try { return window[area].getItem(k); } catch { return null; } },
    set(area, k, v) { try { window[area].setItem(k, v); } catch { /* blocked */ } },
    del(area, k) { try { window[area].removeItem(k); } catch { /* blocked */ } },
  };

  /* =====================================================================
   *  settings / look
   * ===================================================================== */
  function applyLook() {
    const root = document.documentElement;
    Themes.apply(Settings.get('theme'));
    root.dataset.motion = Settings.get('motion') ? 'on' : 'off';
    root.dataset.compact = Settings.get('compact') ? '1' : '0';
    root.dataset.blur = Settings.get('blurOnHide') ? '1' : '0';
    root.style.setProperty('--scale', String(Settings.get('fontScale') / 100));
    Ui.setCompact(Settings.get('compact'));
    buildThemeGrid();
  }

  function buildThemeGrid() {
    const grid = $('theme-grid');
    grid.textContent = '';
    const entries = Object.entries(Themes.PRESETS).concat([['custom', Themes.getCustom()]]);
    for (const [name, t] of entries) {
      grid.append(
        h(
          'button',
          {
            class: 'swatch' + (Settings.get('theme') === name ? ' is-active' : ''),
            type: 'button',
            'aria-label': `${t.label || name} theme`,
            vars: { '--sw-bg': t.bg, '--sw-ink': t.ink, '--sw-accent': t.accent, '--sw-hot': t.hot },
            on: { click: () => { Settings.set('theme', name); applyLook(); } },
          },
          h('i'),
          t.label || name
        )
      );
    }
  }

  function bindSettings() {
    const toggle = (id, key) => {
      const el = $(id);
      el.checked = !!Settings.get(key);
      el.addEventListener('change', () => { Settings.set(key, el.checked); if (['motion', 'compact', 'blurOnHide'].includes(key)) applyLook(); });
    };
    toggle('set-sound', 'sound');
    toggle('set-24h', 'hour24');
    toggle('set-compact', 'compact');
    toggle('set-motion', 'motion');
    toggle('set-boot', 'boot');
    toggle('set-remember', 'rememberRooms');
    toggle('set-wipe-close', 'wipeOnClose');
    toggle('set-blur', 'blurOnHide');

    const fs = $('set-fontscale');
    fs.value = String(Settings.get('fontScale'));
    fs.addEventListener('input', () => { Settings.set('fontScale', Number(fs.value)); applyLook(); });

    $('set-remember').addEventListener('change', persistRooms);

    // translation
    const sel = $('set-translate-to');
    for (const [code, name] of Translate.LANGS) sel.append(h('option', { value: code, text: name }));
    sel.value = Settings.get('translateTo');
    sel.addEventListener('change', () => Settings.set('translateTo', sel.value));
    const tr = $('set-translate');
    tr.checked = Settings.get('translate') && Translate.supported();
    tr.addEventListener('change', () => Settings.set('translate', tr.checked));
    if (!Translate.supported()) {
      tr.checked = false;
      tr.disabled = true;
      sel.disabled = true;
      $('translate-note').textContent =
        "Your browser has no on-device translator (recent Chrome or Edge do). We don't fall back to a cloud translator, because that would show your messages to a third party.";
    } else {
      $('translate-note').textContent = 'Runs entirely on your device. Messages never go to a translation service.';
    }

    // custom theme
    const ct = Themes.getCustom();
    $('ct-bg').value = ct.bg; $('ct-panel').value = ct.panel; $('ct-ink').value = ct.ink;
    $('ct-accent').value = ct.accent; $('ct-hot').value = ct.hot;
    $('ct-radius').value = ct.radius; $('ct-shadow').value = ct.shadow; $('ct-mono').checked = ct.mono;
    const readCustom = () => ({
      bg: $('ct-bg').value, panel: $('ct-panel').value, ink: $('ct-ink').value, accent: $('ct-accent').value, hot: $('ct-hot').value,
      radius: $('ct-radius').value, shadow: $('ct-shadow').value, mono: $('ct-mono').checked,
    });
    const useCustom = () => {
      if (!Themes.saveCustom(readCustom())) return false;
      Settings.set('theme', 'custom');
      applyLook();
      return true;
    };
    for (const id of ['ct-bg', 'ct-panel', 'ct-ink', 'ct-accent', 'ct-hot', 'ct-radius', 'ct-shadow', 'ct-mono']) {
      $(id).addEventListener('input', useCustom); // live preview
      $(id).addEventListener('change', useCustom);
    }
    $('ct-use').addEventListener('click', () => { if (useCustom()) Ui.toast('Custom theme applied.'); });
    $('ct-share').addEventListener('click', async () => {
      const code = Themes.exportCode(Themes.saveCustom(readCustom()));
      Ui.toast((await Ui.copy(code)) ? 'Theme code copied. Send it to a friend.' : code);
    });
    $('ct-import').addEventListener('click', () => {
      const t = Themes.importCode($('ct-code').value);
      if (!t) return Ui.toast("That doesn't look like a theme code.", 'error');
      Themes.saveCustom(t);
      $('ct-bg').value = t.bg; $('ct-panel').value = t.panel; $('ct-ink').value = t.ink;
      $('ct-accent').value = t.accent; $('ct-hot').value = t.hot; $('ct-radius').value = t.radius;
      $('ct-shadow').value = t.shadow; $('ct-mono').checked = t.mono;
      $('ct-code').value = '';
      Settings.set('theme', 'custom');
      applyLook();
      Ui.toast('Theme loaded.');
    });

    $('btn-forget-rooms').addEventListener('click', async () => {
      if (!(await Ui.confirmBox({ title: 'Forget saved rooms?', text: "They'll no longer reopen on this device. You'll need the join code to get back in.", ok: 'Forget' }))) return;
      try { localStorage.removeItem(ROOMS_KEY); } catch { /* ignore */ }
      Ui.toast('Saved rooms forgotten.');
    });
    $('btn-panic').addEventListener('click', async () => {
      if (!(await Ui.confirmBox({ title: 'Wipe everything?', text: 'Signs you out and erases every setting, saved room and key on this device. Messages are never saved anyway.', ok: 'Wipe it all' }))) return;
      panic();
    });
    $('btn-logout').addEventListener('click', logout);
  }

  async function panic() {
    try { await Api.logout(); } catch { /* offline is fine */ }
    Vault.wipe();
    try { PeerSession.teardown(); } catch { /* not connected */ }
    Net.disconnect();
    try {
      Object.keys(localStorage).filter((k) => k.startsWith('zent_')).forEach((k) => localStorage.removeItem(k));
      sessionStorage.clear();
    } catch { /* storage blocked */ }
    location.replace('/');
  }

  async function logout() {
    try { await Api.logout(); } catch { /* ignore */ }
    Vault.wipe();
    try { PeerSession.teardown(); } catch { /* ignore */ }
    Net.disconnect();
    try { localStorage.removeItem(ROOMS_KEY); } catch { /* ignore */ }
    location.reload();
  }

  /* =====================================================================
   *  first-load intro
   * ===================================================================== */
  function runBoot() {
    return new Promise((resolve) => {
      if (!Settings.get('boot') || !Settings.get('motion') || store.get('sessionStorage', 'zent_booted') || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return resolve();
      store.set('sessionStorage', 'zent_booted', '1');
      const el = $('boot');
      const out = $('boot-text');
      const lines = ['ZENT//SIGNAL  v2', 'gathering entropy ........ ok', 'sealing the room .......... ok', 'logs ...................... none', 'ready.'];
      const text = lines.join('\n');
      el.classList.add('is-on');
      let i = 0;
      let finished = false;
      const done = () => {
        if (finished) return;
        finished = true;
        clearInterval(t);
        el.classList.add('is-off');
        setTimeout(() => { el.classList.remove('is-on', 'is-off'); resolve(); }, 450);
      };
      const t = setInterval(() => {
        out.textContent = text.slice(0, ++i);
        if (i >= text.length) setTimeout(done, 260);
      }, 16);
      el.addEventListener('pointerdown', done, { once: true });
      document.addEventListener('keydown', done, { once: true });
    });
  }

  /* =====================================================================
   *  sign in
   * ===================================================================== */
  function showAuth() {
    $('app').classList.add('is-hidden');
    $('auth-screen').classList.remove('is-hidden');
    $('login-username').focus({ preventScroll: true });
  }

  function authError(msg) {
    const box = $('auth-error');
    box.textContent = msg;
    box.classList.remove('is-hidden');
    box.style.animation = 'none';
    void box.offsetWidth;
    box.style.animation = '';
  }

  function busy(btn, on) {
    btn.disabled = on;
    btn.classList.toggle('is-busy', on);
  }

  function switchAuthTab(which) {
    const login = which === 'login';
    $('tab-login').classList.toggle('is-active', login);
    $('tab-register').classList.toggle('is-active', !login);
    $('login-form').classList.toggle('is-hidden', !login);
    $('register-form').classList.toggle('is-hidden', login);
    $('auth-error').classList.add('is-hidden');
  }

  function bindAuth() {
    $('tab-login').addEventListener('click', () => switchAuthTab('login'));
    $('tab-register').addEventListener('click', () => switchAuthTab('register'));

    const submit = (formId, fn) =>
      $(formId).addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = e.target.querySelector('button[type=submit]');
        $('auth-error').classList.add('is-hidden');
        busy(btn, true);
        try {
          enter(await fn());
        } catch (err) {
          authError(err.message);
        } finally {
          busy(btn, false);
        }
      });
    submit('login-form', () => Api.login($('login-username').value.trim(), $('login-password').value, $('login-remember').checked));
    submit('register-form', () => Api.register($('register-username').value.trim(), $('register-password').value, $('register-remember').checked));

    $('guest-btn').addEventListener('click', async () => {
      const btn = $('guest-btn');
      busy(btn, true);
      $('auth-error').classList.add('is-hidden');
      try {
        enter(await Api.guest($('login-remember').checked));
      } catch (err) {
        authError(err.message);
      } finally {
        busy(btn, false);
      }
    });

    Api.hooks.start = () => $('pow-overlay').classList.remove('is-hidden');
    Api.hooks.end = () => $('pow-overlay').classList.add('is-hidden');
  }

  /* =====================================================================
   *  entering the app
   * ===================================================================== */
  function enter(me) {
    state.me = { id: me.id, username: me.username, role: me.role, uid: null };
    state.ready = false;
    state.rooms.clear();
    state.rooms.set(PUBLIC, makeRoom({ key: PUBLIC, type: 'public', name: 'public' }));
    state.current = PUBLIC;
    $('login-password').value = '';
    $('register-password').value = '';
    try { sessionStorage.setItem('zent_tab', '1'); } catch { /* ignore */ }

    $('me-name').textContent = me.username;
    $('me-role').textContent = me.role === 'guest' ? 'Guest · 24h' : 'Member';
    $('me-avatar').textContent = me.username.charAt(0);
    $('account-line').textContent = `Signed in as ${me.username}`;

    Ui.swapScreen($('app'), $('auth-screen'));
    renderRooms();
    renderFriends();
    connectSocket();
    loadFriends();
    handleHash();
  }

  /* =====================================================================
   *  socket
   * ===================================================================== */
  function connectSocket() {
    Ui.setSignal('wait');
    Net.connect({
      onConnect() {
        Ui.setSignal('up');
        $('offline-banner').classList.add('is-hidden');
      },
      onDisconnect(reason) {
        Ui.setSignal(reason === 'io server disconnect' ? 'down' : 'wait');
        showBanner(reason === 'io server disconnect' ? 'The server closed your connection.' : 'Connection lost. Trying to reconnect…');
        updateComposer();
      },
      onConnectError(err) {
        if (err && err.message === 'Unauthorized') {
          Ui.toast('Your session ended. Please sign in again.', 'error');
          Net.disconnect();
          showAuth();
        } else {
          Ui.setSignal('down');
          showBanner(err && err.message === 'Too many connections' ? 'Too many connections from your network right now.' : "Can't reach the server. Retrying…");
        }
      },
      onIdle: () => showBanner('You were disconnected for being idle.'),
      onReady: onReady,
      onPresenceJoin: ({ room, username, uid }) => {
        // ignore our own join, which the server announces just before it tells us who we are
        if (!state.me.uid || uid === state.me.uid || !state.rooms.has(room)) return;
        Ui.addSystem(room, `${username} joined`);
      },
      onPresenceLeave: ({ room, username, uid }) => {
        if (uid !== state.me.uid && state.rooms.has(room)) Ui.addSystem(room, `${username} left`);
      },
      onCount: ({ room, count }) => {
        const r = state.rooms.get(room);
        if (!r) return;
        r.count = count;
        if (r.type === 'dm' && count < 2) r.peerHere = false;
        if (room === state.current) updateHeader();
        renderRooms();
      },
      onMessage: (m) => enqueue(m),
      onTyping: onTyping,
      onExpired: ({ room, reason }) => handleExpired(room, reason),
      onKicked: ({ room, reason }) => {
        Ui.toast(reason);
        removeRoomLocal(room);
      },
      onDmKey: onDmKey,
      onDmRing: onDmRing,
      onFriendsChanged: onFriendsChanged,
      onFriendPresence: ({ id, online }) => {
        if (online) state.online.add(id); else state.online.delete(id);
        renderFriends();
      },
      onServerError: ({ message }) => Ui.toast(message, 'error'),
    });
  }

  function showBanner(text) {
    $('offline-text').textContent = text;
    $('offline-banner').classList.remove('is-hidden');
  }

  async function onReady(data) {
    state.me.uid = data.uid;
    const first = !state.ready;
    state.ready = true;
    if (first) {
      switchTo(PUBLIC);
      Ui.setEmpty(PUBLIC, [h('div', {}, h('b', { text: '# public' }), ' is open to everyone.'), h('div', { text: 'Say hi. Nothing here is ever saved.' })]);
      await restoreRooms();
      refreshOnline();
    } else {
      await rejoinAll();
    }
  }

  async function rejoinAll() {
    for (const r of Array.from(state.rooms.values())) {
      if (r.type === 'code') {
        const res = await Net.join({ locator: r.key.slice(2), auth: r.auth });
        if (!res.ok) { removeRoomLocal(r.key); continue; }
        r.expiresAt = res.room.expiresAt;
      } else if (r.type === 'dm') {
        const res = await Net.join({ room: r.key });
        if (!res.ok) { removeRoomLocal(r.key); continue; }
        r.peerHere = false;
        r.ready = false;
        await startKeyExchange(r);
      }
    }
    refreshOnline();
    renderRooms();
    updateHeader();
  }

  async function refreshOnline() {
    const res = await Net.friendsOnline();
    if (res && Array.isArray(res.online)) {
      state.online = new Set(res.online);
      renderFriends();
    }
  }

  /* =====================================================================
   *  rooms
   * ===================================================================== */
  function roomTitle(r) {
    if (r.type === 'dm') return r.peerName;
    if (r.type === 'p2p') return 'direct link';
    return r.name;
  }

  function switchTo(key) {
    const r = state.rooms.get(key);
    if (!r) return;
    state.current = key;
    r.unread = 0;
    if (r.type === 'dm') state.ringing.delete(r.peerId);
    Ui.showLog(key);
    Ui.setTyping(null);
    updateHeader();
    renderRooms();
    renderFriends();
    updateBadges();
    closeRail();
    if (!matchMedia('(max-width: 820px)').matches) $('composer-input').focus({ preventScroll: true });
  }

  function updateHeader() {
    const r = state.rooms.get(state.current);
    if (!r) return;
    const prefix = r.type === 'dm' ? '@' : r.type === 'p2p' ? '↔' : '#';
    $('room-prefix').textContent = prefix;
    $('room-title').textContent = roomTitle(r);
    $('room-count').textContent = r.type === 'p2p' ? '' : r.count ? `${r.count} here` : '';
    $('room-share').classList.toggle('is-hidden', r.type !== 'code');
    $('room-leave').classList.toggle('is-hidden', r.type !== 'code');
    updateExpiryPill();
    updateComposer();

    const who = r.peerName ? r.peerName.toUpperCase() : '';
    if (r.type === 'public') {
      Ui.setMode('open', 'OPEN', 'PUBLIC ROOM · EVERYONE CAN READ THIS · NOTHING IS STORED · BE KIND');
    } else if (r.type === 'code') {
      Ui.setMode('sealed', 'SEALED', 'END TO END ENCRYPTED · ONLY PEOPLE WITH THE CODE CAN READ THIS · THE SERVER ONLY SEES SCRAMBLED BYTES');
    } else if (r.type === 'dm') {
      if (r.ready && r.count >= 2) Ui.setMode('sealed', 'SEALED', `END TO END ENCRYPTED · SAFETY CODE ${r.safety} · COMPARE IT WITH ${who} TO BE SURE NO ONE IS IN THE MIDDLE`);
      else Ui.setMode('wait', 'WAITING', `WAITING FOR ${who} TO COME ONLINE · NOTHING IS STORED SO MESSAGES CAN'T WAIT FOR THEM`);
    } else {
      Ui.setMode('p2p', 'P2P', "DIRECT LINK · PEER TO PEER · THE SERVER CAN'T SEE THIS AT ALL · CLOSING THE TAB ENDS IT");
    }
  }

  function updateComposer() {
    const r = state.rooms.get(state.current);
    const input = $('composer-input');
    let enabled = true;
    let ph = 'Say something…';
    let max = 1000;
    if (!r) enabled = false;
    else if (r.type === 'public') ph = 'Message #public (everyone can read it)';
    else if (r.type === 'code') { ph = `Message #${r.name} (encrypted)`; max = 1500; }
    else if (r.type === 'dm') {
      max = 1500;
      if (r.ready && r.count >= 2) ph = `Message @${r.peerName} (encrypted)`;
      else { enabled = false; ph = `Waiting for ${r.peerName} to come online…`; }
    } else if (r.type === 'p2p') { ph = 'Message (peer to peer, encrypted)'; max = 1500; }
    if (!Net.isConnected() && r && r.type !== 'p2p') { enabled = false; ph = 'Offline. Reconnecting…'; }
    input.disabled = !enabled;
    $('send-btn').disabled = !enabled;
    input.placeholder = ph;
    input.maxLength = max;
  }

  function renderRooms() {
    const list = $('room-list');
    list.textContent = '';
    const rooms = Array.from(state.rooms.values()).filter((r) => r.type !== 'dm');
    rooms.sort((a, b) => (a.type === 'public' ? -1 : b.type === 'public' ? 1 : (a.expiresAt || 0) - (b.expiresAt || 0)));
    for (const r of rooms) {
      const sub = h('span', { class: 'item-sub', text: subText(r) });
      r._sub = sub;
      list.append(
        h(
          'li',
          { class: 'item' + (r.key === state.current ? ' is-active' : ''), role: 'button', tabindex: '0', on: { click: () => switchTo(r.key), keydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); switchTo(r.key); } } } },
          h('span', { class: 'item-hash', text: r.type === 'p2p' ? '↔' : '#' }),
          h('span', { class: 'item-main' }, h('span', { class: 'item-name', text: roomTitle(r) }), sub),
          r.unread ? h('span', { class: 'badge', text: r.unread > 99 ? '99+' : String(r.unread) }) : null
        )
      );
    }
    updateBadges();
  }

  function subText(r) {
    if (r.type === 'public') return r.count ? `${r.count} online · open to all` : 'open to all';
    if (r.type === 'p2p') return 'peer to peer';
    const rem = r.expiresAt ? Ui.fmtRemaining(r.expiresAt - Date.now()) : '';
    return `${r.count || 1} here · burns in ${rem}`;
  }

  function updateBadges() {
    const rUnread = Array.from(state.rooms.values()).filter((r) => r.type !== 'dm').reduce((n, r) => n + r.unread, 0);
    const fUnread = Array.from(state.rooms.values()).filter((r) => r.type === 'dm').reduce((n, r) => n + r.unread, 0) + state.ringing.size;
    const set = (id, n) => { $(id).textContent = n > 99 ? '99+' : String(n); $(id).classList.toggle('is-hidden', !n); };
    set('rooms-badge', rUnread);
    set('friends-badge', fUnread);
    const total = rUnread + fUnread;
    document.title = (total ? `(${total}) ` : '') + SITE_TITLE;
  }

  function removeRoomLocal(key) {
    const r = state.rooms.get(key);
    if (!r || r.key === PUBLIC) return;
    state.rooms.delete(key);
    Vault.forget(key);
    Ui.removeLog(key);
    if (r.type === 'code') persistRooms();
    if (state.current === key) switchTo(PUBLIC);
    else { renderRooms(); renderFriends(); }
  }

  async function handleExpired(key, reason) {
    const r = state.rooms.get(key);
    if (!r) return;
    Ui.toast(reason === 'empty' ? `“${r.name}” burned, everyone left.` : `“${r.name}” burned. Time's up.`);
    state.rooms.delete(key);
    Vault.forget(key);
    persistRooms();
    const wasCurrent = state.current === key;
    if (wasCurrent) Ui.addSystem(key, 'This room burned.', true);
    await Ui.burnLog(key);
    if (wasCurrent) switchTo(PUBLIC);
    else { renderRooms(); }
  }

  /* ---- remembering rooms on this device (only if the setting is on) ---- */
  function persistRooms() {
    try {
      if (!Settings.get('rememberRooms')) return localStorage.removeItem(ROOMS_KEY);
      const saved = Array.from(state.rooms.values())
        .filter((r) => r.type === 'code')
        .map((r) => ({ code: r.code, name: r.name, expiresAt: r.expiresAt }));
      if (saved.length) localStorage.setItem(ROOMS_KEY, JSON.stringify(saved));
      else localStorage.removeItem(ROOMS_KEY);
    } catch { /* storage blocked */ }
  }

  async function restoreRooms() {
    if (!Settings.get('rememberRooms')) return;
    let saved = [];
    try { saved = JSON.parse(localStorage.getItem(ROOMS_KEY) || '[]'); } catch { saved = []; }
    if (!Array.isArray(saved)) return;
    for (const s of saved.slice(0, 8)) {
      if (!s || typeof s.code !== 'string' || (s.expiresAt && s.expiresAt < Date.now())) continue;
      await joinByCode(s.code, { quiet: true });
    }
    persistRooms();
  }

  /* ---- joining with a code ---- */
  async function joinByCode(codeInput, { quiet = false } = {}) {
    const parsed = Vault.parseJoinCode(codeInput);
    if (!parsed) return { ok: false, error: "That code doesn't look right. It has 16 letters and numbers." };
    const key = `c:${parsed.locator}`;
    if (state.rooms.has(key)) { if (!quiet) switchTo(key); return { ok: true, room: state.rooms.get(key) }; }
    const { auth } = await Vault.deriveRoom(parsed.locator, parsed.secret);
    const res = await Net.join({ locator: parsed.locator, auth });
    if (!res.ok) { Vault.forget(key); return res; }
    const room = makeRoom({ key, type: 'code', name: res.room.name, code: parsed.normalized, auth, expiresAt: res.room.expiresAt, count: res.room.count });
    state.rooms.set(key, room);
    Ui.setEmpty(key, [h('div', {}, 'You\u2019re in ', h('b', { text: room.name }), '.'), h('div', { text: 'Everything here is encrypted in your browser.' })]);
    persistRooms();
    renderRooms();
    if (!quiet) switchTo(key);
    return { ok: true, room };
  }

  function bindRooms() {
    // tabs
    document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => showTab(t.dataset.tab)));

    $('open-create').addEventListener('click', () => openCreate());
    $('open-join').addEventListener('click', () => { $('jn-error').classList.add('is-hidden'); Ui.openModal('dlg-join'); });
    document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => Ui.closeModal(b.closest('.modal').id)));
    document.querySelectorAll('.modal').forEach((m) => m.addEventListener('click', (e) => { if (e.target === m && m.id !== 'dlg-confirm') Ui.closeModal(m.id); }));

    // join form
    $('jn-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = $('jn-submit');
      busy(btn, true);
      $('jn-error').classList.add('is-hidden');
      try {
        const res = await joinByCode($('jn-code').value);
        if (res.ok) { Ui.closeModal('dlg-join'); $('jn-code').value = ''; }
        else { $('jn-error').textContent = res.error; $('jn-error').classList.remove('is-hidden'); }
      } finally { busy(btn, false); }
    });
    $('jn-code').addEventListener('input', () => { $('jn-error').classList.add('is-hidden'); });

    // create form
    $('cr-ttl').addEventListener('change', () => $('cr-custom').classList.toggle('is-hidden', $('cr-ttl').value !== 'custom'));
    $('cr-form').addEventListener('submit', onCreateSubmit);
    $('cr-copy-code').addEventListener('click', async () => Ui.toast((await Ui.copy(state.createdRoom.code)) ? 'Code copied.' : state.createdRoom.code));
    $('cr-copy-link').addEventListener('click', async () => {
      const link = `${location.origin}/#join=${state.createdRoom.code}`;
      Ui.toast((await Ui.copy(link)) ? 'Invite link copied.' : link);
    });
    $('cr-open').addEventListener('click', () => { Ui.closeModal('dlg-create'); switchTo(state.createdRoom.key); });

    $('room-share').addEventListener('click', () => {
      const r = state.rooms.get(state.current);
      if (r && r.type === 'code') showCreateResult(r, 'Share this room');
    });
    $('room-leave').addEventListener('click', async () => {
      const r = state.rooms.get(state.current);
      if (!r || r.type !== 'code') return;
      if (!(await Ui.confirmBox({ title: `Leave “${r.name}”?`, text: 'You can come back with the join code until the room burns.', ok: 'Leave' }))) return;
      await Net.leave(r.key);
      removeRoomLocal(r.key);
    });
  }

  function openCreate() {
    $('cr-form').classList.remove('is-hidden');
    $('cr-result').classList.add('is-hidden');
    $('cr-title').textContent = 'New room';
    $('cr-error').classList.add('is-hidden');
    Ui.openModal('dlg-create');
  }

  function ttlFromForm() {
    if ($('cr-ttl').value !== 'custom') return Number($('cr-ttl').value);
    const n = Math.max(1, Number($('cr-custom-num').value) || 0);
    return n * Number($('cr-custom-unit').value);
  }

  async function onCreateSubmit(e) {
    e.preventDefault();
    const btn = $('cr-submit');
    const err = (m) => { $('cr-error').textContent = m; $('cr-error').classList.remove('is-hidden'); };
    $('cr-error').classList.add('is-hidden');
    const name = $('cr-name').value.trim();
    if (!name) return err('Give the room a name.');
    const ttlMs = ttlFromForm();
    if (ttlMs < 5 * 60 * 1000) return err('Rooms last at least 5 minutes.');
    if (ttlMs > 7 * 24 * 3600 * 1000) return err('Rooms last at most 7 days.');
    busy(btn, true);
    try {
      let res = null, parsed = null, auth = null;
      for (let attempt = 0; attempt < 6; attempt++) { // a locator can (rarely) collide; just roll a new code
        parsed = Vault.parseJoinCode(Vault.generateJoinCode());
        ({ auth } = await Vault.deriveRoom(parsed.locator, parsed.secret));
        res = await Net.create({ name, locator: parsed.locator, auth, ttlMs, burnWhenEmpty: $('cr-burn').checked });
        if (res.ok || res.error !== 'taken') break;
        Vault.forget(`c:${parsed.locator}`);
      }
      if (!res.ok) { Vault.forget(`c:${parsed.locator}`); return err(res.error === 'taken' ? 'Please try again.' : res.error); }
      const key = `c:${parsed.locator}`;
      const room = makeRoom({ key, type: 'code', name: res.room.name, code: parsed.normalized, auth, expiresAt: res.room.expiresAt, count: res.room.count });
      state.rooms.set(key, room);
      Ui.setEmpty(key, [h('div', {}, h('b', { text: room.name }), ' is ready.'), h('div', { text: 'Share the join code. Only people with it can read this.' })]);
      persistRooms();
      renderRooms();
      $('cr-name').value = '';
      showCreateResult(room, 'Room created');
    } finally {
      busy(btn, false);
    }
  }

  function showCreateResult(room, title) {
    state.createdRoom = room;
    $('cr-title').textContent = title;
    $('cr-code').textContent = room.code;
    $('cr-expires').textContent = `Burns ${new Date(room.expiresAt).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })}. Everything in it disappears then.`;
    $('cr-form').classList.add('is-hidden');
    $('cr-result').classList.remove('is-hidden');
    Ui.openModal('dlg-create');
  }

  /* ---- countdowns (once a second) ---- */
  function updateExpiryPill() {
    const r = state.rooms.get(state.current);
    const pill = $('expiry-pill');
    if (!r || !r.expiresAt) return pill.classList.add('is-hidden');
    const rem = r.expiresAt - Date.now();
    pill.classList.remove('is-hidden');
    pill.classList.toggle('is-urgent', rem < 60000);
    $('expiry-text').textContent = Ui.fmtRemaining(rem);
  }

  function tick() {
    const now = Date.now();
    for (const r of Array.from(state.rooms.values())) {
      if (r.type !== 'code' || !r.expiresAt) continue;
      if (r.expiresAt - now < -6000) { handleExpired(r.key, 'expired'); continue; } // the server normally tells us first
      if (r._sub) r._sub.textContent = subText(r);
    }
    updateExpiryPill();
  }

  /* =====================================================================
   *  friends
   * ===================================================================== */
  function showTab(name) {
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('is-active', t.dataset.tab === name));
    document.querySelectorAll('.pane').forEach((p) => p.classList.toggle('is-active', p.id === `tab-${name}`));
    if (name === 'friends') { state.ringing.size && updateBadges(); loadMyCode(); }
  }

  async function loadMyCode() {
    try {
      const { friendCode, expiresAt } = await Api.friendCode();
      $('friend-code-text').textContent = friendCode;
      $('friend-code-expiry').textContent = expiresAt ? `Temporary. Resets in about ${Math.max(1, Math.round((expiresAt - Date.now()) / 3600000))}h. Make an account to keep one forever.` : 'Yours for keeps. Share it so people can add you.';
    } catch { /* offline */ }
  }

  async function loadFriends() {
    loadMyCode();
    try {
      const { friends } = await Api.friends();
      state.friends = friends;
      for (const f of friends) {
        const r = state.rooms.get(f.room);
        if (r) r.peerName = f.username;
      }
    } catch { /* offline */ }
    renderFriends();
  }

  async function onFriendsChanged() {
    const before = new Set(state.friends.map((f) => f.id));
    await loadFriends();
    const gone = Array.from(before).filter((id) => !state.friends.some((f) => f.id === id));
    for (const id of gone) {
      const r = Array.from(state.rooms.values()).find((x) => x.type === 'dm' && x.peerId === id);
      if (r) removeRoomLocal(r.key);
    }
    const added = state.friends.filter((f) => !before.has(f.id) && !state.justAdded.has(f.id));
    if (added.length) Ui.toast(`${added[0].username} added you as a friend.`);
    if (state.friends.some((f) => !before.has(f.id))) refreshOnline();
  }

  function renderFriends() {
    const list = $('friend-list');
    list.textContent = '';
    $('friends-empty').classList.toggle('is-hidden', state.friends.length > 0);
    for (const f of state.friends) {
      const room = state.rooms.get(f.room);
      const ringing = state.ringing.has(f.id);
      const unread = room ? room.unread : 0;
      list.append(
        h(
          'li',
          { class: 'item' + (f.room === state.current ? ' is-active' : ''), role: 'button', tabindex: '0', on: { click: () => openDm(f), keydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openDm(f); } } } },
          h('span', { class: 'dot' + (state.online.has(f.id) ? ' is-on' : ''), title: state.online.has(f.id) ? 'online' : 'offline' }),
          h('span', { class: 'item-main' }, h('span', { class: 'item-name', text: f.username }), h('span', { class: 'item-sub', text: ringing ? 'wants to chat' : f.role === 'guest' ? 'guest' : state.online.has(f.id) ? 'online' : 'offline' })),
          unread || ringing ? h('span', { class: 'badge', text: unread ? String(unread) : '!' }) : null,
          h('button', { class: 'item-x', type: 'button', 'aria-label': `Remove ${f.username}`, title: 'Remove friend', on: { click: (e) => { e.stopPropagation(); removeFriend(f); } } }, '✕')
        )
      );
    }
    updateBadges();
  }

  async function removeFriend(f) {
    if (!(await Ui.confirmBox({ title: `Remove ${f.username}?`, text: 'You will both lose this private chat. You can add each other again later.', ok: 'Remove' }))) return;
    try { await Api.removeFriend(f.id); Ui.toast(`${f.username} removed.`); } catch (e) { Ui.toast(e.message, 'error'); }
    await loadFriends();
    const r = state.rooms.get(f.room);
    if (r) removeRoomLocal(r.key);
  }

  function bindFriends() {
    $('add-friend-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const code = $('add-friend-input').value.trim();
      if (!code) return;
      try {
        const { friend } = await Api.addFriend(code);
        state.justAdded.add(friend.id);
        $('add-friend-input').value = '';
        Ui.toast(`You and ${friend.username} are friends now.`);
        await loadFriends();
        refreshOnline();
      } catch (err) {
        Ui.toast(err.message, 'error');
      }
    });
    $('copy-friend-code').addEventListener('click', async () => {
      const code = $('friend-code-text').textContent;
      Ui.toast((await Ui.copy(code)) ? 'Friend code copied.' : code);
    });
  }

  /* ---- direct messages: automatic key exchange, nothing to type ---- */
  async function openDm(friend) {
    let room = state.rooms.get(friend.room);
    if (!room) {
      room = makeRoom({ key: friend.room, type: 'dm', name: friend.username, peerId: friend.id, peerName: friend.username, ready: false, peerHere: false, safety: null });
      state.rooms.set(friend.room, room);
    }
    const res = await Net.join({ room: friend.room });
    if (!res.ok) { state.rooms.delete(friend.room); Ui.toast(res.error, 'error'); return; }
    room.count = res.room.count;
    state.ringing.delete(friend.id);
    await startKeyExchange(room);
    if (!Ui.getLog(room.key).el.querySelector('.msg')) {
      Ui.setEmpty(room.key, [h('div', {}, 'Private chat with ', h('b', { text: friend.username }), '.'), h('div', { text: "No passwords. Your browsers agree on a key by themselves. Compare the safety code in the bar above if you want to be sure." })]);
    }
    switchTo(room.key);
  }

  async function startKeyExchange(room) {
    try {
      const pub = await Vault.dmBegin(room.key);
      Net.dmKey({ room: room.key, pub, kind: 'hello' });
    } catch (e) {
      Ui.toast('Could not start the secure handshake.', 'error');
    }
  }

  async function onDmKey({ room: key, pub, kind }) {
    const room = state.rooms.get(key);
    if (!room || room.type !== 'dm') return;
    try {
      const mine = await Vault.dmBegin(key);
      const previous = room.safety;
      const fp = await Vault.dmAccept(key, pub);
      room.ready = true;
      room.safety = fp;
      room.peerHere = true;
      if (previous && previous !== fp) Ui.addSystem(key, `Safety code changed to ${fp}. ${room.peerName} may have reopened the chat, or someone is in the middle. Compare codes to be sure.`, true);
      if (kind === 'hello') Net.dmKey({ room: key, pub: mine, kind: 'ack' });
      if (key === state.current) updateHeader();
    } catch {
      Ui.addSystem(key, 'Received an invalid key from the other side. Ignoring it.', true);
    }
  }

  function onDmRing({ room, from, username }) {
    const f = state.friends.find((x) => x.id === from);
    if (!f || (state.current === room)) return;
    state.ringing.add(from);
    renderFriends();
    Ui.toast(`${username} opened a chat with you.`);
    playTick();
  }

  /* =====================================================================
   *  messages
   * ===================================================================== */
  const queues = new Map();
  function enqueue(msg) {
    const prev = queues.get(msg.room) || Promise.resolve();
    queues.set(msg.room, prev.then(() => handleMessage(msg)).catch(() => {}));
  }

  async function handleMessage(msg) {
    const room = state.rooms.get(msg.room);
    if (!room) return;
    const own = msg.uid === state.me.uid;
    let text = msg.text;
    let failed = false;
    if (room.type !== 'public') {
      text = await Vault.open(room.key, msg.ciphertext, msg.iv);
      if (text === null) { failed = true; text = 'Could not decrypt this message.'; }
    }
    const nodes = Ui.addMessage(room.key, { uid: msg.uid, sender: msg.sender, text, ts: msg.ts, own, failed }, { hour24: Settings.get('hour24') });
    clearTyping(room.key, msg.uid);

    if (!own) {
      const looking = room.key === state.current && !document.hidden;
      if (!looking) { room.unread += 1; room.type === 'dm' ? renderFriends() : renderRooms(); }
      if (Settings.get('sound') && !looking) playTick();
      if (!failed && Settings.get('translate')) translateInto(nodes, text);
    }
  }

  async function translateInto(nodes, original) {
    const target = Settings.get('translateTo');
    const r = await Translate.run(original, target);
    const label = (from) => Translate.label(from);
    if (r.status === 'ok') {
      showTranslated(nodes, original, r.text, r.from);
    } else if (r.status === 'needs-download') {
      nodes.row.append(
        h('div', { class: 'msg-tr' }, h('span', { text: `${label(r.from)} → ${label(target)}` }),
          h('button', { type: 'button', text: 'Translate (downloads a small language pack)', on: { click: async (e) => {
            e.target.disabled = true;
            const rr = await Translate.run(original, target, { gesture: true });
            e.target.closest('.msg-tr').remove();
            if (rr.status === 'ok') showTranslated(nodes, original, rr.text, rr.from);
            else Ui.toast("Couldn't translate that one.", 'error');
          } } }))
      );
    }
  }

  function showTranslated(nodes, original, translated, from) {
    let shown = true;
    nodes.body.textContent = translated;
    const btn = h('button', { type: 'button', text: 'show original' });
    const bar = h('div', { class: 'msg-tr' }, h('span', { text: `translated from ${Translate.label(from)}` }), btn);
    btn.addEventListener('click', () => {
      shown = !shown;
      nodes.body.textContent = shown ? translated : original;
      btn.textContent = shown ? 'show original' : 'show translation';
    });
    nodes.row.append(bar);
  }

  /* ---- sending ---- */
  async function send() {
    if (state.sending) return;
    const r = state.rooms.get(state.current);
    const input = $('composer-input');
    const text = input.value.replace(/\s+/g, ' ').trim();
    if (!r || !text) return;
    state.sending = true;
    try {
      if (r.type === 'p2p') {
        await PeerSession.sendMessage(text);
        Ui.addMessage(P2P, { uid: state.me.uid, sender: 'you', text, ts: Date.now(), own: true }, { hour24: Settings.get('hour24') });
        input.value = '';
        return;
      }
      let res;
      if (r.type === 'public') {
        res = await Net.send({ room: PUBLIC, text });
      } else {
        if (!Vault.isReady(r.key)) return Ui.toast('This chat is not unlocked yet.', 'error');
        res = await Net.send({ room: r.key, ...(await Vault.seal(r.key, text)) });
      }
      if (res.ok) input.value = '';
      else Ui.toast(res.error || "Couldn't send that.", 'error');
    } catch (e) {
      Ui.toast(e.message || "Couldn't send that.", 'error');
    } finally {
      state.sending = false;
      if (!matchMedia('(max-width: 820px)').matches) input.focus({ preventScroll: true });
    }
  }

  /* ---- typing indicator ---- */
  let lastTypingSent = 0;
  function onTyping({ room, username, uid }) {
    if (uid === state.me.uid) return;
    let m = state.typing.get(room);
    if (!m) state.typing.set(room, (m = new Map()));
    if (m.has(uid)) clearTimeout(m.get(uid).timer);
    m.set(uid, { name: username, timer: setTimeout(() => clearTyping(room, uid), 3200) });
    refreshTyping();
  }
  function clearTyping(room, uid) {
    const m = state.typing.get(room);
    if (m && m.has(uid)) { clearTimeout(m.get(uid).timer); m.delete(uid); refreshTyping(); }
  }
  function refreshTyping() {
    const m = state.typing.get(state.current);
    const names = m ? Array.from(m.values()).map((x) => x.name) : [];
    Ui.setTyping(names.length === 0 ? null : names.length === 1 ? `${names[0]} is typing` : names.length === 2 ? `${names[0]} and ${names[1]} are typing` : 'several people are typing');
  }

  function bindComposer() {
    $('composer').addEventListener('submit', (e) => { e.preventDefault(); send(); });
    $('composer-input').addEventListener('input', () => {
      const now = Date.now();
      const r = state.rooms.get(state.current);
      if (r && r.type !== 'p2p' && now - lastTypingSent > 1500) { lastTypingSent = now; Net.typing(state.current); }
    });
    $('jump-btn').addEventListener('click', () => Ui.scrollToEnd(state.current));
    $('reconnect-btn').addEventListener('click', () => { showBanner('Reconnecting…'); Ui.setSignal('wait'); Net.reconnect(); });
  }

  /* =====================================================================
   *  link tab (peer to peer)
   * ===================================================================== */
  function showP2pPanel(which) {
    ['idle', 'waiting', 'connected'].forEach((p) => $(`p2p-${p}`).classList.toggle('is-hidden', p !== which));
  }

  const peerId = (raw) => { const m = String(raw).match(/p2p-([A-Za-z0-9-]+)/); return m ? m[1] : (String(raw).trim() || null); };

  function bindLink() {
    PeerSession.on('status', (status, err) => {
      if (status === 'secure') {
        showP2pPanel('connected');
        if (!state.rooms.has(P2P)) {
          state.rooms.set(P2P, makeRoom({ key: P2P, type: 'p2p', name: 'direct link', count: 2 }));
          Ui.addSystem(P2P, 'Connected. Peer to peer. The server cannot see this conversation.');
        }
        renderRooms();
        showTab('rooms');
        switchTo(P2P);
      } else if (status === 'closed') {
        if (state.rooms.has(P2P)) { Ui.toast('The direct chat ended.'); endP2p(); }
        showP2pPanel('idle');
      } else if (status === 'error') {
        Ui.toast((err && err.message) || 'Could not connect.', 'error');
        showP2pPanel('idle');
      }
    });
    PeerSession.on('message', (text) => {
      Ui.addMessage(P2P, { uid: 'p2p-peer', sender: 'them', text: text === null ? 'Could not decrypt this message.' : text, ts: Date.now(), failed: text === null }, { hour24: Settings.get('hour24') });
      const r = state.rooms.get(P2P);
      if (r && state.current !== P2P) { r.unread += 1; renderRooms(); }
      if (Settings.get('sound') && (state.current !== P2P || document.hidden)) playTick();
    });

    $('p2p-host-btn').addEventListener('click', async () => {
      try {
        const { link } = await PeerSession.host();
        $('p2p-link-text').value = link;
        showP2pPanel('waiting');
      } catch (e) { Ui.toast('Could not start a link: ' + (e.message || 'unknown error'), 'error'); }
    });
    $('p2p-copy-link').addEventListener('click', async () => Ui.toast((await Ui.copy($('p2p-link-text').value)) ? 'Link copied.' : 'Select the link and copy it.'));
    $('p2p-join-btn').addEventListener('click', async () => {
      const id = peerId($('p2p-join-input').value);
      if (!id) return Ui.toast("That link or code doesn't look right.", 'error');
      try { await PeerSession.join(id); } catch (e) { Ui.toast('Could not connect: ' + (e.message || 'unknown error'), 'error'); }
    });
    $('p2p-cancel-btn').addEventListener('click', () => { PeerSession.teardown(); showP2pPanel('idle'); });
    $('p2p-leave-btn').addEventListener('click', () => { PeerSession.teardown(); endP2p(); showP2pPanel('idle'); });
  }

  function endP2p() {
    state.rooms.delete(P2P);
    Ui.removeLog(P2P);
    $('p2p-link-text').value = '';
    $('p2p-join-input').value = '';
    if (state.current === P2P) switchTo(PUBLIC); else renderRooms();
  }

  /* =====================================================================
   *  links like  /#join=CODE  and  /#p2p-ID
   * ===================================================================== */
  function handleHash() {
    const hash = location.hash;
    if (!hash) return;
    history.replaceState(null, '', location.pathname + location.search); // keep codes out of the address bar/history
    const code = Vault.parseJoinCode(hash);
    if (/join=/.test(hash) && code) {
      $('jn-code').value = code.normalized;
      $('jn-error').classList.add('is-hidden');
      Ui.openModal('dlg-join');
      Ui.toast('Someone sent you a room invite. Press Join to enter.');
    } else if (/p2p-/.test(hash)) {
      $('p2p-join-input').value = hash.replace(/^#/, '');
      showTab('link');
      openRail();
      Ui.toast('Press Connect to open the direct link.');
    }
  }

  /* =====================================================================
   *  chrome: rail, drawer, shortcuts, tab visibility
   * ===================================================================== */
  function openRail() { $('rail').classList.add('is-open'); $('app').classList.add('rail-open'); }
  function closeRail() { $('rail').classList.remove('is-open'); $('app').classList.remove('rail-open'); }
  function openSettings() { $('settings').classList.add('is-open'); $('settings').setAttribute('aria-hidden', 'false'); closeRail(); $('settings-close').focus({ preventScroll: true }); }
  function closeSettings() { $('settings').classList.remove('is-open'); $('settings').setAttribute('aria-hidden', 'true'); }

  function bindChrome() {
    $('rail-open').addEventListener('click', openRail);
    $('rail-close').addEventListener('click', closeRail);
    $('scrim').addEventListener('click', closeRail);
    $('open-settings').addEventListener('click', openSettings);
    $('settings-close').addEventListener('click', closeSettings);

    document.addEventListener('pointerdown', (e) => {
      const s = $('settings');
      if (s.classList.contains('is-open') && !s.contains(e.target) && !$('open-settings').contains(e.target) && !e.target.closest('.modal')) closeSettings();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const m = Ui.topModal();
        if (m && m !== 'dlg-confirm') Ui.closeModal(m);
        else if ($('settings').classList.contains('is-open')) closeSettings();
        else closeRail();
      } else if (e.key === '/' && !$('app').classList.contains('is-hidden') && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName) && !$('composer-input').disabled) {
        e.preventDefault();
        $('composer-input').focus();
      }
    });

    // keep the connection alive while you're actually using the page
    let lastAct = 0;
    for (const ev of ['keydown', 'pointerdown']) {
      addEventListener(ev, () => { const n = Date.now(); if (n - lastAct > 60000) { lastAct = n; Net.activity(); } }, { passive: true });
    }

    const away = () => document.documentElement.classList.toggle('is-away', document.hidden || !document.hasFocus());
    document.addEventListener('visibilitychange', () => {
      away();
      if (!document.hidden) { const r = state.rooms.get(state.current); if (r && r.unread) { r.unread = 0; renderRooms(); renderFriends(); } }
    });
    addEventListener('blur', away);
    addEventListener('focus', away);
  }

  let audioCtx = null;
  function playTick() {
    if (!Settings.get('sound')) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const t = audioCtx.currentTime;
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = 'square';
      o.frequency.setValueAtTime(880, t);
      o.frequency.exponentialRampToValueAtTime(440, t + 0.07);
      g.gain.setValueAtTime(0.04, t);
      g.gain.exponentialRampToValueAtTime(0.0008, t + 0.09);
      o.connect(g).connect(audioCtx.destination);
      o.start(t);
      o.stop(t + 0.1);
    } catch { /* audio not available */ }
  }

  /* =====================================================================
   *  start
   * ===================================================================== */
  async function maybeSignOutOnClose() {
    // sessionStorage lives exactly as long as this tab, so a missing flag means a fresh tab.
    let fresh = false;
    try { fresh = !sessionStorage.getItem('zent_tab'); } catch { /* ignore */ }
    if (Settings.get('wipeOnClose') && fresh) {
      try { await Api.logout(); } catch { /* ignore */ }
      try { localStorage.removeItem(ROOMS_KEY); } catch { /* ignore */ }
    }
    try { sessionStorage.setItem('zent_tab', '1'); } catch { /* ignore */ }
  }

  async function start() {
    applyLook();
    bindSettings();
    bindAuth();
    bindRooms();
    bindFriends();
    bindComposer();
    bindLink();
    bindChrome();
    setInterval(tick, 1000);

    try {
      await maybeSignOutOnClose();
      await runBoot();
    } catch { /* the intro and tab cleanup are optional; carry on */ }
    try {
      enter(await Api.me());
    } catch {
      showAuth();
    }
  }

  start();
})();
