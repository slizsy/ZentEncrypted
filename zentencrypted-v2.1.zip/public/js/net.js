/**
 * net.js
 * Owns the Socket.io connection. Turns server events into handler
 * callbacks and turns emits into promises with a timeout.
 */
const Net = (() => {
  let socket = null;

  function emit(event, payload, timeoutMs = 8000) {
    return new Promise((resolve) => {
      if (!socket || !socket.connected) return resolve({ ok: false, error: "You're offline right now." });
      const t = setTimeout(() => resolve({ ok: false, error: 'The server took too long to answer.' }), timeoutMs);
      socket.emit(event, payload, (res) => {
        clearTimeout(t);
        resolve(res || { ok: false, error: 'No response.' });
      });
    });
  }

  function connect(h) {
    socket = io({ withCredentials: true, reconnectionDelayMax: 8000 });
    const on = (ev, name) => socket.on(ev, (...a) => h[name] && h[name](...a));
    on('connect', 'onConnect');
    on('disconnect', 'onDisconnect');
    on('connect_error', 'onConnectError');
    on('session:ready', 'onReady');
    on('presence:join', 'onPresenceJoin');
    on('presence:leave', 'onPresenceLeave');
    on('room:count', 'onCount');
    on('message:receive', 'onMessage');
    on('typing', 'onTyping');
    on('room:expired', 'onExpired');
    on('room:kicked', 'onKicked');
    on('dm:key', 'onDmKey');
    on('dm:ring', 'onDmRing');
    on('friends:changed', 'onFriendsChanged');
    on('friend:presence', 'onFriendPresence');
    on('session:idle', 'onIdle');
    on('server:error', 'onServerError');
    return socket;
  }

  return {
    connect,
    reconnect: () => socket && socket.connect(),
    disconnect: () => socket && socket.disconnect(),
    isConnected: () => !!(socket && socket.connected),
    join: (p) => emit('room:join', p),
    create: (p) => emit('room:create', p),
    leave: (room) => emit('room:leave', { room }),
    send: (p) => emit('message:send', p),
    friendsOnline: () => emit('friends:online', {}),
    typing: (room) => socket && socket.connected && socket.emit('typing', { room }),
    dmKey: (p) => socket && socket.connected && socket.emit('dm:key', p),
    activity: () => socket && socket.connected && socket.emit('activity'),
  };
})();
