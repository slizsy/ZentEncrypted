/**
 * crypto.js  (Vault)
 * All encryption happens here, in the browser, with the native Web Crypto API.
 *
 * JOIN-CODE ROOMS
 *   code  = LLLL-SSSS-SSSS-SSSS   (L = public locator, S = secret, 60 bits)
 *   PBKDF2(secret, salt=locator, 150k iterations) -> 512 bits
 *     first 256 bits  -> "auth"  sent to the server to prove you know the code
 *     last  256 bits  -> AES-256-GCM key, NEVER leaves the browser
 *   The server stores only a hash of "auth". It cannot recover the key.
 *
 * DIRECT MESSAGES (friends)
 *   Each browser makes a throw-away ECDH P-256 keypair per conversation,
 *   swaps public keys through the server, and both derive the same AES key.
 *   Nothing to type. A short "safety code" (hash of both public keys) lets
 *   friends confirm out-of-band that nobody sat in the middle.
 *
 * PUBLIC ROOM: not encrypted — it's public. See server.js / README.
 */
const Vault = (() => {
  const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I
  const ITERATIONS = 150000;
  const AES = { name: 'AES-GCM', length: 256 };
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  const keys = new Map(); // roomKey -> CryptoKey
  const dms = new Map(); // roomKey -> { priv, pub, fp }

  const toB64 = (buf) => {
    const b = new Uint8Array(buf);
    let s = '';
    for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
    return btoa(s);
  };
  const fromB64 = (b64) => {
    const s = atob(b64);
    const b = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
    return b;
  };
  const toHex = (buf) => Array.from(new Uint8Array(buf), (x) => x.toString(16).padStart(2, '0')).join('');

  /* ---------------- join codes ---------------- */
  function generateJoinCode() {
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    let raw = '';
    for (const b of bytes) raw += ALPHABET[b & 31]; // 256 % 32 == 0, so no modulo bias
    return format(raw);
  }

  function format(raw) {
    return raw.match(/.{4}/g).join('-');
  }

  /** Accepts "abcd efgh-ijkl mnop", full links with #join=..., etc. */
  function parseJoinCode(input) {
    if (typeof input !== 'string') return null;
    let s = input;
    const m = s.match(/join=([A-Za-z0-9-]+)/);
    if (m) s = m[1];
    s = s.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (s.length !== 16) return null;
    for (const ch of s) if (!ALPHABET.includes(ch)) return null;
    return { locator: s.slice(0, 4), secret: s.slice(4), normalized: format(s) };
  }

  async function deriveRoom(locator, secret) {
    const base = await crypto.subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt: enc.encode('zent-room-v2:' + locator), iterations: ITERATIONS, hash: 'SHA-256' },
      base,
      512
    );
    const bytes = new Uint8Array(bits);
    const roomKey = `c:${locator}`;
    keys.set(roomKey, await crypto.subtle.importKey('raw', bytes.slice(32), AES, false, ['encrypt', 'decrypt']));
    return { roomKey, auth: toHex(bytes.slice(0, 32)) };
  }

  /* ---------------- direct messages ---------------- */
  async function dmBegin(roomKey) {
    let st = dms.get(roomKey);
    if (!st) {
      const pair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
      const pub = toB64(await crypto.subtle.exportKey('raw', pair.publicKey));
      st = { priv: pair.privateKey, pub, fp: null, peer: null };
      dms.set(roomKey, st);
    }
    return st.pub;
  }

  /** Returns the safety code both friends should see. */
  async function dmAccept(roomKey, theirPubB64) {
    const st = dms.get(roomKey);
    if (!st) throw new Error('Start the key exchange first.');
    if (st.peer === theirPubB64 && keys.has(roomKey)) return st.fp;
    const theirBytes = fromB64(theirPubB64);
    if (theirBytes.length !== 65 || theirBytes[0] !== 4) throw new Error('Bad public key.');
    const theirKey = await crypto.subtle.importKey('raw', theirBytes, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
    const shared = await crypto.subtle.deriveBits({ name: 'ECDH', public: theirKey }, st.priv, 256);

    const pubs = [st.pub, theirPubB64].sort().join('|');
    const pubsHash = await crypto.subtle.digest('SHA-256', enc.encode(pubs));
    const hkdfBase = await crypto.subtle.importKey('raw', shared, 'HKDF', false, ['deriveKey']);
    keys.set(
      roomKey,
      await crypto.subtle.deriveKey(
        { name: 'HKDF', hash: 'SHA-256', salt: pubsHash, info: enc.encode('zent-dm-v2:' + roomKey) },
        hkdfBase,
        AES,
        false,
        ['encrypt', 'decrypt']
      )
    );
    const hex = toHex(pubsHash).slice(0, 8).toUpperCase();
    st.peer = theirPubB64;
    st.fp = `${hex.slice(0, 4)}-${hex.slice(4)}`;
    return st.fp;
  }

  const dmSafetyCode = (roomKey) => (dms.get(roomKey) || {}).fp || null;

  /* ---------------- sealing ---------------- */
  const isReady = (roomKey) => keys.has(roomKey);

  async function seal(roomKey, plaintext) {
    const key = keys.get(roomKey);
    if (!key) throw new Error('This conversation is not unlocked yet.');
    const iv = crypto.getRandomValues(new Uint8Array(12));
    // AAD binds the ciphertext to its room, so it can't be replayed elsewhere.
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: enc.encode(roomKey) }, key, enc.encode(plaintext));
    return { ciphertext: toB64(ct), iv: toB64(iv) };
  }

  /** Returns the text, or null if it can't be decrypted. */
  async function open(roomKey, ciphertextB64, ivB64) {
    const key = keys.get(roomKey);
    if (!key) return null;
    try {
      const pt = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: fromB64(ivB64), additionalData: enc.encode(roomKey) },
        key,
        fromB64(ciphertextB64)
      );
      return dec.decode(pt);
    } catch {
      return null;
    }
  }

  const forget = (roomKey) => {
    keys.delete(roomKey);
    dms.delete(roomKey);
  };
  const wipe = () => {
    keys.clear();
    dms.clear();
  };

  return { generateJoinCode, parseJoinCode, deriveRoom, dmBegin, dmAccept, dmSafetyCode, isReady, seal, open, forget, wipe };
})();
