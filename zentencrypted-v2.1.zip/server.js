/**
 * server.js
 * Entry point: Express + Socket.io + (self-hosted) PeerJS signaling.
 */
require('dotenv').config();

const path = require('path');
const http = require('http');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const { Server } = require('socket.io');
const { ExpressPeerServer } = require('peer');
const { WebSocketServer } = require('ws');

const authRoutes = require('./src/auth');
const friendsRoutes = require('./src/friends');
const realtime = require('./src/realtime');
const shield = require('./src/shield');

const app = express();
const server = http.createServer(app);

// cloudflared (or nginx) runs on this machine and talks to us over loopback;
// trusting only loopback keeps X-Forwarded-* spoof-proof from the LAN.
app.set('trust proxy', 'loopback');

app.use(
  helmet({
    hsts: false, // TLS is handled by Cloudflare; Node may also be reached over plain http on the LAN
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        fontSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'", 'ws:', 'wss:'],
        workerSrc: ["'self'"],
        manifestSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
      },
    },
  })
);

app.use(express.json({ limit: '20kb' }));
app.use(cookieParser());

app.use('/api', (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});
app.use('/api/auth', authRoutes);
app.use('/api/friends', friendsRoutes);
app.get('/health', (req, res) => res.json({ ok: true }));

app.use(
  express.static(path.join(__dirname, 'public'), {
    setHeaders(res, filePath) {
      if (/\.(woff2|png|ico|svg)$/.test(filePath)) res.set('Cache-Control', 'public, max-age=604800');
      else res.set('Cache-Control', 'no-cache'); // JS/CSS/HTML revalidate so updates show up
    },
  })
);

const extraOrigins = (process.env.CORS_ORIGIN || '').split(',').map((s) => s.trim()).filter(Boolean);

const io = new Server(server, {
  maxHttpBufferSize: realtime.MAX_PAYLOAD_BYTES + 2048,
  // Refuse cross-site WebSocket handshakes: the Origin must match our own host.
  allowRequest(req, cb) {
    const origin = req.headers.origin;
    if (!origin) return cb(null, true);
    try {
      const host = req.headers['x-forwarded-host'] || req.headers.host;
      cb(null, new URL(origin).host === host || extraOrigins.includes(origin));
    } catch {
      cb(null, false);
    }
  },
});
realtime.attach(io);

// Self-hosted WebRTC signaling for the "Link" (peer-to-peer) tab. It only
// brokers the handshake; messages in that mode never touch this server.
//
// IMPORTANT: PeerJS normally attaches its own WebSocket server directly to
// `server`, and the `ws` library answers every upgrade that isn't for its
// path with "400 Bad Request" — which kills Socket.io's websocket transport.
// So we hand PeerJS a detached (noServer) WebSocket server and route the
// upgrade requests ourselves: /peerjs/* -> PeerJS, everything else -> Socket.io.
let peerWss = null;
const peerServer = ExpressPeerServer(server, {
  path: '/',
  allow_discovery: false,
  proxied: true,
  concurrent_limit: 300,
  createWebSocketServer: (opts) => (peerWss = new WebSocketServer({ noServer: true, path: opts.path })),
});
app.use('/peerjs', peerServer);

server.on('upgrade', (req, socket, head) => {
  if (!peerWss) return;
  const pathname = String(req.url || '').split('?')[0];
  if (pathname !== peerWss.options.path) return; // not ours: Socket.io handles /socket.io/
  const origin = req.headers.origin;
  if (origin) {
    let ok = false;
    try {
      ok = new URL(origin).host === (req.headers['x-forwarded-host'] || req.headers.host) || extraOrigins.includes(origin);
    } catch { /* bad Origin header */ }
    if (!ok) return socket.destroy();
  }
  peerWss.handleUpgrade(req, socket, head, (ws) => peerWss.emit('connection', ws, req));
});

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`ZentEncrypted listening on port ${PORT}`);
    if (shield.status().config.always) console.log('Shield: ALWAYS-ON human check is enabled.');
  });
}

module.exports = { app, server, io };
